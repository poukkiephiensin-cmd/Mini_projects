#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ER Diagram — ລະບົບຮ້ານຂາຍເສື້ອຜ້າອອນລາຍ (5 ຕາຕະລາງ)
ສ້າງຮູບ PNG ດ້ວຍ Pillow + raqm (ຮອງຮັບການຈັບຄູ່ຕົວອັກສອນລາວ)
"""
from PIL import Image, ImageDraw, ImageFont

REG = "/home/user/.fonts/NotoSansLao-Regular.ttf"
BLD = "/home/user/.fonts/NotoSansLao-Bold.ttf"
_fc = {}


def F(size, bold=False):
    k = (size, bold)
    if k not in _fc:
        _fc[k] = ImageFont.truetype(BLD if bold else REG, size)
    return _fc[k]


TABLES = {
    "customers": dict(
        title="customers", sub="ລູກຄ້າ", color="#2563eb", x=70, y=120, w=340,
        cols=[
            ("customer_id", "INT", "PK"),
            ("full_name", "VARCHAR(100)", ""),
            ("gender", "ENUM", ""),
            ("phone", "VARCHAR(20)", "UQ"),
            ("email", "VARCHAR(100)", "UQ"),
            ("password_hash", "VARCHAR(255)", ""),
            ("address", "VARCHAR(255)", ""),
            ("city", "VARCHAR(100)", ""),
            ("created_at", "DATETIME", ""),
        ]),
    "products": dict(
        title="products", sub="ສິນຄ້າ", color="#059669", x=1050, y=120, w=400,
        cols=[
            ("product_id", "INT", "PK"),
            ("product_name", "VARCHAR(150)", ""),
            ("category", "VARCHAR(50)", ""),
            ("brand", "VARCHAR(80)", ""),
            ("size", "VARCHAR(20)", ""),
            ("color", "VARCHAR(40)", ""),
            ("description", "TEXT", ""),
            ("price", "DECIMAL(12,2)", ""),
            ("cost_price", "DECIMAL(12,2)", ""),
            ("stock_qty", "INT", ""),
            ("image_url", "VARCHAR(255)", ""),
            ("status", "ENUM", ""),
            ("created_at", "DATETIME", ""),
        ]),
    "orders": dict(
        title="orders", sub="ຄຳສັ່ງຊື້", color="#7c3aed", x=70, y=470, w=340,
        cols=[
            ("order_id", "INT", "PK"),
            ("customer_id", "INT", "FK"),
            ("order_date", "DATETIME", ""),
            ("status", "ENUM", ""),
            ("subtotal", "DECIMAL(12,2)", ""),
            ("shipping_fee", "DECIMAL(12,2)", ""),
            ("discount", "DECIMAL(12,2)", ""),
            ("total_amount", "DECIMAL(12,2)", ""),
            ("shipping_address", "VARCHAR(255)", ""),
            ("note", "VARCHAR(255)", ""),
            ("created_at", "DATETIME", ""),
        ]),
    "payments": dict(
        title="payments", sub="ການຊຳລະເງິນ", color="#db2777", x=570, y=470, w=400,
        cols=[
            ("payment_id", "INT", "PK"),
            ("order_id", "INT", "FK"),
            ("payment_method", "ENUM", ""),
            ("amount", "DECIMAL(12,2)", ""),
            ("payment_status", "ENUM", ""),
            ("transaction_ref", "VARCHAR(100)", ""),
            ("paid_at", "DATETIME", ""),
            ("created_at", "DATETIME", ""),
        ]),
    "order_items": dict(
        title="order_items", sub="ລາຍລະອຽດຄຳສັ່ງຊື້", color="#d97706", x=570, y=850, w=400,
        cols=[
            ("item_id", "INT", "PK"),
            ("order_id", "INT", "FK"),
            ("product_id", "INT", "FK"),
            ("size", "VARCHAR(20)", ""),
            ("color", "VARCHAR(40)", ""),
            ("quantity", "INT", ""),
            ("unit_price", "DECIMAL(12,2)", ""),
            ("line_total", "GENERATED", ""),
        ]),
}

HDR, ROW, PAD = 52, 27, 12
for t in TABLES.values():
    t["h"] = HDR + len(t["cols"]) * ROW + PAD

W, H = 1520, 1200
S = 2

img = Image.new("RGB", (W * S, H * S), "#f8fafc")
d = ImageDraw.Draw(img)


def rect(box, r, fill=None, outline=None, width=1):
    d.rounded_rectangle([c * S for c in box], radius=r * S, fill=fill,
                        outline=outline, width=int(width * S))


def text(xy, s, font, fill, anchor="la"):
    d.text((xy[0] * S, xy[1] * S), s, font=font, fill=fill, anchor=anchor)


def line(pts, fill="#475569", w=2.4):
    d.line([(x * S, y * S) for x, y in pts], fill=fill, width=int(w * S), joint="curve")


def tri(pts, fill="#475569"):
    d.polygon([(x * S, y * S) for x, y in pts], fill=fill)


C, P, O, PA, OI = (TABLES[k] for k in ("customers", "products", "orders", "payments", "order_items"))
LBL, LBLC = F(19), "#475569"

# 1) customers (1) -> orders (N)
x = C["x"] + 170
y1, y2 = C["y"] + C["h"], O["y"]
line([(x, y1), (x, y2 - 13)])
tri([(x, y2 - 1), (x - 7, y2 - 14), (x + 7, y2 - 14)])
text((x + 13, y1 + 12), "1", F(19, True), "#1e293b")
text((x + 13, y2 - 44), "N", F(19, True), "#1e293b")
text((x - 14, (y1 + y2) / 2 + 2), "ສັ່ງຊື້", F(19), LBLC, anchor="rm")

# 2) orders (1) -> payments (N)
xa, ya = O["x"] + O["w"], O["y"] + 52
xb = PA["x"]
line([(xa, ya), (xb - 13, ya)])
tri([(xb - 1, ya), (xb - 14, ya - 7), (xb - 14, ya + 7)])
text((xa + 11, ya - 32), "1", F(19, True), "#1e293b")
text((xb - 26, ya - 32), "N", F(19, True), "#1e293b", anchor="ra")
text(((xa + xb) / 2, ya + 10), "ຊຳລະ", LBL, LBLC, anchor="ma")

# 3) orders (1) -> order_items (N)  ລົງແລ້ວຂວາ
xa3, ya3 = O["x"] + 60, O["y"] + O["h"]
yb3 = OI["y"] + 90
line([(xa3, ya3), (xa3, yb3), (OI["x"] - 13, yb3)])
tri([(OI["x"] - 1, yb3), (OI["x"] - 14, yb3 - 7), (OI["x"] - 14, yb3 + 7)])
text((xa3 + 12, ya3 + 10), "1", F(19, True), "#1e293b")
text((OI["x"] - 26, yb3 - 34), "N", F(19, True), "#1e293b", anchor="ra")
text((xa3 + 14, (ya3 + yb3) / 2 - 6), "ມີລາຍການ", LBL, LBLC, anchor="lm")

# 4) products (1) -> order_items (N)  ທາງຂວາສຸດ
xp, yp = P["x"] + P["w"], P["y"] + 170
yr = OI["y"] + 46
xc = 1490
line([(xp, yp), (xc, yp), (xc, yr), (OI["x"] + OI["w"] + 13, yr)])
tri([(OI["x"] + OI["w"] + 1, yr), (OI["x"] + OI["w"] + 14, yr - 7), (OI["x"] + OI["w"] + 14, yr + 7)])
text((xp + 12, yp - 32), "1", F(19, True), "#1e293b")
text((OI["x"] + OI["w"] + 26, yr - 34), "N", F(19, True), "#1e293b", anchor="ra")
text((xc - 16, (yp + yr) / 2), "ຖືກສັ່ງຊື້", LBL, LBLC, anchor="rm")

# ---------------- ກ່ອງຕາຕະລາງ ----------------
for t in TABLES.values():
    x, y, w, h, c = t["x"], t["y"], t["w"], t["h"], t["color"]
    rect((x + 4, y + 7, x + w + 4, y + h + 7), 12, fill="#e2e8f0")
    rect((x, y, x + w, y + h), 12, fill="#ffffff")
    rect((x, y, x + w, y + HDR), 12, fill=c)
    rect((x, y + HDR - 13, x + w, y + HDR), 0, fill=c)
    text((x + 16, y + 9), t["title"], F(23, True), "#ffffff")
    text((x + w - 16, y + 14), t["sub"], F(19), "#ffffff", anchor="ra")
    for i, (name, typ, key) in enumerate(t["cols"]):
        ry = y + HDR + i * ROW + ROW / 2
        if i % 2 == 0:
            rect((x + 1, ry - ROW / 2, x + w - 1, ry + ROW / 2), 0, fill="#f6f8fb")
        if key:
            bc = "#1d4ed8" if key == "PK" else ("#b45309" if key == "FK" else "#64748b")
            rect((x + 12, ry - 11, x + 46, ry + 11), 5, fill=bc)
            text((x + 29, ry), key, F(14, True), "#ffffff", anchor="mm")
            text((x + 56, ry), name, F(17, True), "#0f172a", anchor="lm")
        else:
            text((x + 56, ry), name, F(17), "#334155", anchor="lm")
        text((x + w - 14, ry), typ, F(15), "#94a3b8", anchor="rm")
    rect((x, y, x + w, y + h), 12, outline=c, width=1.6)
    d.line([((x + 14) * S, (y + HDR) * S), ((x + w - 14) * S, (y + HDR) * S)],
           fill=c, width=2 * S)

# ---------------- ຫົວຂໍ້ ----------------
text((W / 2, 44), "ER Diagram — ລະບົບຮ້ານຂາຍເສື້ອຜ້າອອນລາຍ", F(38, True), "#0f172a", anchor="mm")
text((W / 2, 84), "5 ຕາຕະລາງ · customers · products · orders · order_items · payments",
     F(21), "#64748b", anchor="mm")

# ---------------- ກ່ອງສະຫຼຸບຄວາມສຳພັນ ----------------
px, py, pw, ph = 1040, 620, 410, 250
rect((px, py, px + pw, py + ph), 12, fill="#ffffff", outline="#cbd5e1")
text((px + 18, py + 14), "ຄວາມສຳພັນ (Relationships)", F(19, True), "#0f172a")
rels = [
    ("customers", "N", "orders", "#2563eb", "#7c3aed", "ລູກຄ້າ 1 ຄົນ ມີຫຼາຍຄຳສັ່ງຊື້"),
    ("orders", "N", "order_items", "#7c3aed", "#d97706", "ບິນ 1 ໃບ ມີຫຼາຍລາຍການສິນຄ້າ"),
    ("products", "N", "order_items", "#059669", "#d97706", "ສິນຄ້າ 1 ຊະນິດ ຖືກສັ່ງຫຼາຍຄັ້ງ"),
    ("orders", "N", "payments", "#7c3aed", "#db2777", "ບິນ 1 ໃບ ອາດມີຫຼາຍການຊຳລະ"),
]
ry = py + 56
for a, n, b, ca, cb, desc in rels:
    # ຈຸດສີ + ຊື່
    d.ellipse([(px + 20) * S, (ry - 5) * S, (px + 30) * S, (ry + 5) * S], fill=ca)
    text((px + 36, ry), a, F(15, True), "#0f172a", anchor="lm")
    text((px + 36 + d.textlength(a, font=F(15, True)) / S + 8, ry), "1 — N", F(15, True), "#64748b", anchor="lm")
    d.ellipse([(px + 132) * S, (ry - 5) * S, (px + 142) * S, (ry + 5) * S], fill=cb)
    text((px + 148, ry), b, F(15, True), "#0f172a", anchor="lm")
    text((px + 18, ry + 24), desc, F(15), "#64748b", anchor="lm")
    ry += 48

# ---------------- legend ----------------
px2, py2 = 1040, 950
rect((px2, py2, px2 + 410, py2 + 110), 10, fill="#ffffff", outline="#cbd5e1")
text((px2 + 16, py2 + 12), "ຄຳອະທິບາຍ", F(16, True), "#0f172a")


def leg(x0, y0, col, badge, label):
    rect((x0, y0 - 10, x0 + 32, y0 + 10), 5, fill=col)
    text((x0 + 16, y0), badge, F(13, True), "#ffffff", anchor="mm")
    text((x0 + 40, y0), label, F(15), "#334155", anchor="lm")


leg(px2 + 16, py2 + 48, "#1d4ed8", "PK", "Primary Key")
leg(px2 + 210, py2 + 48, "#b45309", "FK", "Foreign Key")
leg(px2 + 16, py2 + 84, "#64748b", "UQ", "Unique")
text((px2 + 210, py2 + 84), "1 : N = ໜຶ່ງ ຕໍ່ ຫຼາຍ", F(15), "#334155", anchor="lm")

img.resize((W, H), Image.LANCZOS).save("/home/user/ER_diagram_ຮ້ານຂາຍເສື້ອຜ້າ.png")
print("saved")
