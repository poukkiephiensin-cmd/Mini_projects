-- ============================================================
-- ຖານຂໍ້ມູນ: ຮ້ານຂາຍເສື້ອຜ້າອອນລາຍ (5 ຕາຕະລາງ)
-- DBMS: MySQL 8 / MariaDB
-- Charset: utf8mb4 (ຮອງຮັບພາສາລາວ)
-- ============================================================

DROP DATABASE IF EXISTS clothing_shop;
CREATE DATABASE clothing_shop
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE clothing_shop;

-- ------------------------------------------------------------
-- 1) ລູກຄ້າ
-- ------------------------------------------------------------
CREATE TABLE customers (
  customer_id   INT           NOT NULL AUTO_INCREMENT,
  full_name     VARCHAR(100)  NOT NULL,
  gender        ENUM('M','F','O') NULL,
  phone         VARCHAR(20)   NOT NULL,
  email         VARCHAR(100)  NULL,
  password_hash VARCHAR(255)  NOT NULL,
  address       VARCHAR(255)  NULL,
  city          VARCHAR(100)  NULL,
  created_at    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (customer_id),
  UNIQUE KEY uq_customers_phone (phone),
  UNIQUE KEY uq_customers_email (email)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 2) ສິນຄ້າ (1 ແຖວ = 1 SKU: ສິນຄ້າ + ຂະໜາດ + ສີ)
-- ------------------------------------------------------------
CREATE TABLE products (
  product_id   INT            NOT NULL AUTO_INCREMENT,
  product_name VARCHAR(150)   NOT NULL,
  category     VARCHAR(50)    NOT NULL,
  brand        VARCHAR(80)    NULL,
  size         VARCHAR(20)    NULL,
  color        VARCHAR(40)    NULL,
  description  TEXT           NULL,
  price        DECIMAL(12,2)  NOT NULL,
  cost_price   DECIMAL(12,2)  NULL,
  stock_qty    INT            NOT NULL DEFAULT 0,
  image_url    VARCHAR(255)   NULL,
  status       ENUM('active','inactive','out_of_stock') NOT NULL DEFAULT 'active',
  created_at   DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (product_id),
  KEY idx_products_category (category),
  CONSTRAINT chk_products_price CHECK (price >= 0),
  CONSTRAINT chk_products_cost  CHECK (cost_price IS NULL OR cost_price >= 0),
  CONSTRAINT chk_products_stock CHECK (stock_qty >= 0)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 3) ຄຳສັ່ງຊື້
-- ------------------------------------------------------------
CREATE TABLE orders (
  order_id         INT           NOT NULL AUTO_INCREMENT,
  customer_id      INT           NOT NULL,
  order_date       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status           ENUM('pending','confirmed','packing','shipped','delivered','cancelled')
                                 NOT NULL DEFAULT 'pending',
  subtotal         DECIMAL(12,2) NOT NULL DEFAULT 0,
  shipping_fee     DECIMAL(12,2) NOT NULL DEFAULT 0,
  discount         DECIMAL(12,2) NOT NULL DEFAULT 0,
  total_amount     DECIMAL(12,2) NOT NULL,
  shipping_address VARCHAR(255)  NOT NULL,
  note             VARCHAR(255)  NULL,
  created_at       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (order_id),
  KEY idx_orders_customer (customer_id),
  KEY idx_orders_date (order_date),
  CONSTRAINT fk_orders_customer FOREIGN KEY (customer_id)
    REFERENCES customers (customer_id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT chk_orders_subtotal CHECK (subtotal >= 0),
  CONSTRAINT chk_orders_total    CHECK (total_amount >= 0)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 4) ລາຍລະອຽດຄຳສັ່ງຊື້
-- ------------------------------------------------------------
CREATE TABLE order_items (
  item_id    INT           NOT NULL AUTO_INCREMENT,
  order_id   INT           NOT NULL,
  product_id INT           NOT NULL,
  size       VARCHAR(20)   NULL,
  color      VARCHAR(40)   NULL,
  quantity   INT           NOT NULL,
  unit_price DECIMAL(12,2) NOT NULL,
  line_total DECIMAL(12,2) GENERATED ALWAYS AS (quantity * unit_price) STORED,
  PRIMARY KEY (item_id),
  KEY idx_items_order   (order_id),
  KEY idx_items_product (product_id),
  CONSTRAINT fk_items_order FOREIGN KEY (order_id)
    REFERENCES orders (order_id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_items_product FOREIGN KEY (product_id)
    REFERENCES products (product_id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT chk_items_qty   CHECK (quantity > 0),
  CONSTRAINT chk_items_price CHECK (unit_price >= 0)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 5) ການຊຳລະເງິນ
-- ------------------------------------------------------------
CREATE TABLE payments (
  payment_id     INT           NOT NULL AUTO_INCREMENT,
  order_id       INT           NOT NULL,
  payment_method ENUM('cod','bank_transfer','credit_card','qr_wallet') NOT NULL,
  amount         DECIMAL(12,2) NOT NULL,
  payment_status ENUM('pending','paid','failed','refunded') NOT NULL DEFAULT 'pending',
  transaction_ref VARCHAR(100) NULL,
  paid_at        DATETIME      NULL,
  created_at     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (payment_id),
  KEY idx_payments_order  (order_id),
  KEY idx_payments_status (payment_status),
  CONSTRAINT fk_payments_order FOREIGN KEY (order_id)
    REFERENCES orders (order_id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_payments_amount CHECK (amount > 0)
) ENGINE=InnoDB;


-- ============================================================
-- ຂໍ້ມູນຕົວຢ່າງ (Sample data)
-- ============================================================

INSERT INTO customers (full_name, gender, phone, email, password_hash, address, city) VALUES
('ສົມພອນ ວົງສະຫວັນ', 'F', '02055511111', 'somphone@example.com', '$2y$10$abcdefghijklmnopqrstuv', 'ບ້ານ ທົ່ງຄັນຄາມ', 'ວຽງຈັນ'),
('ຄຳພອນ ສີສຸວັນ',   'M', '02055522222', 'khamphon@example.com', '$2y$10$abcdefghijklmnopqrstuv', 'ບ້ານ ສີສັດຕະນາກ', 'ວຽງຈັນ'),
('ນາລີ ພົມມະຈັນ',   'F', '02055533333', NULL,                   '$2y$10$abcdefghijklmnopqrstuv', 'ບ້ານ ດອນກອຍ',      'ວຽງຈັນ');

INSERT INTO products (product_name, category, brand, size, color, description, price, cost_price, stock_qty) VALUES
('ເສື້ອຢືດຄໍກົມ',      'ເສື້ອ', 'LaoStyle', 'M',  'ດຳ',   'ຜ້າຝ້າຍ 100%',        120000, 70000, 40),
('ເສື້ອຢືດຄໍກົມ',      'ເສື້ອ', 'LaoStyle', 'L',  'ດຳ',   'ຜ້າຝ້າຍ 100%',        120000, 70000, 25),
('ເສື້ອເຊີດຍາວ',       'ເສື້ອ', 'Bloom',    'S',  'ຂາວ',  'ເຊີດຍາວແຂນສັ້ນ',       180000, 110000, 30),
('ສິ້ນຊີ້ງລາຍ',        'ສິ້ນ',  'SilkLao',  'M',  'ແດງ',  'ຜ້າໄໝລາວ',            350000, 220000, 15),
('ໂສ້ງຂາຍາວຢີນ',     'ໂສ້ງ',  'DenimCo',  '32', 'ຄີມ',  'ໂສ້ງຢີນຜ້າໜາ',          250000, 160000, 20),
('ໝວກບີນນີ',        'ໝວກ',  'CapLao',   'Free','ດຳ',  'ໝວກປັບຂະໜາດໄດ້',       45000,  25000, 60);

INSERT INTO orders (customer_id, status, subtotal, shipping_fee, discount, total_amount, shipping_address, note) VALUES
(1, 'delivered', 420000, 20000, 0,     440000, 'ບ້ານ ທົ່ງຄັນຄາມ, ວຽງຈັນ', 'ສົ່ງຕອນເຊົ້າ'),
(2, 'shipped',   530000, 20000, 30000, 520000, 'ບ້ານ ສີສັດຕະນາກ, ວຽງຈັນ', NULL),
(3, 'pending',   120000, 15000, 0,     135000, 'ບ້ານ ດອນກອຍ, ວຽງຈັນ',      NULL);

INSERT INTO order_items (order_id, product_id, size, color, quantity, unit_price) VALUES
(1, 1, 'M',  'ດຳ',  2, 120000),
(1, 6, 'Free','ດຳ',  4, 45000),
(2, 3, 'S',  'ຂາວ', 1, 180000),
(2, 4, 'M',  'ແດງ', 1, 350000),
(3, 1, 'M',  'ດຳ',  1, 120000);

INSERT INTO payments (order_id, payment_method, amount, payment_status, transaction_ref, paid_at) VALUES
(1, 'cod',           440000, 'paid',   NULL,           '2026-10-28 10:15:00'),
(2, 'bank_transfer', 520000, 'paid',   'BCEL-8842103', '2026-11-05 14:02:00'),
(3, 'qr_wallet',     135000, 'pending', NULL,          NULL);


-- ============================================================
-- ຄຳຖາມຕົວຢ່າງ
-- ============================================================

-- ຍອດຂາຍລາຍວັນ
SELECT DATE(order_date) AS ວັນທີ, COUNT(*) AS ຈຳນວນບິນ, SUM(total_amount) AS ຍອດຂາຍ
FROM orders
WHERE status <> 'cancelled'
GROUP BY DATE(order_date)
ORDER BY ວັນທີ DESC;

-- ສິນຄ້າຂາຍດີ 10 ອັນດັບຕົ້ນ
SELECT p.product_name, SUM(oi.quantity) AS ຈຳນວນຂາຍ
FROM order_items oi
JOIN products p ON p.product_id = oi.product_id
JOIN orders   o ON o.order_id   = oi.order_id
WHERE o.status <> 'cancelled'
GROUP BY p.product_id, p.product_name
ORDER BY ຈຳນວນຂາຍ DESC
LIMIT 10;
