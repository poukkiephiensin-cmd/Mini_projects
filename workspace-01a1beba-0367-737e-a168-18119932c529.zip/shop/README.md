# ສິລປະ ບູຕິກ — ລະບົບຮ້ານຂາຍເສື້ອຜ້າອອນລາຍ

ເວັບໄຊຮ້ານຂາຍເສື້ອຜ້າອອນລາຍ ພັດທະນາດ້ວຍ **HTML + CSS + JavaScript + PHP + MySQL**
ໃຊ້ຖານຂໍ້ມູນ **5 ຕາຕະລາງ** ຕາມການອອກແບບ: `customers`, `products`, `orders`, `order_items`, `payments`

---

## 1. ຄຸນສົມບັດ

### ຝ່າຍລູກຄ້າ
| ໜ້າ | ລາຍລະອຽດ |
|-----|-----------|
| `index.php` | ໜ້າຫຼັກ — hero, ສິນຄ້າໃໝ່, ສິນຄ້າຂາຍດີ, ຄົ້ນຫາ ແລະ ກອງຕາມໝວດ |
| `product.php` | ລາຍລະອຽດສິນຄ້າ + ເພີ່ມໃສ່ກະຕ່າ + ສິນຄ້າທີ່ຄ້າຍກັນ |
| `cart.php` | ກະຕ່າ — ເພີ່ມ/ຫຼຸດຈຳນວນ, ລຶບ, ຄິດໄລ່ຍອດລວມ |
| `checkout.php` | ທີ່ຢູ່ຈັດສົ່ງ + ເລືອກຊ່ອງທາງຊຳລະ (COD / ໂອນ / QR / ບັດ) |
| `order_success.php` | ໜ້າສຳເລັດ + ສະຫຼຸບບິນ |
| `orders.php` | ລາຍການຄຳສັ່ງຊື້ + timeline ສະຖານະ |
| `order_detail.php` | ລາຍລະອຽດບິນ ແລະ ການຊຳລະ |
| `register.php` / `login.php` / `logout.php` | ສະໝັກ ແລະ ເຂົ້າສູ່ລະບົບ |
| `profile.php` | ແກ້ໄຂໂປຣໄຟລ໌ ແລະ ປ່ຽນລະຫັດຜ່ານ |

### ຝ່າຍຜູ້ດູແລລະບົບ (`/admin/`)
| ໜ້າ | ລາຍລະອຽດ |
|-----|-----------|
| `index.php` | ແດຊບອດ — ຍອດຂາຍ, ກຣາຟ 7 ວັນ (SVG), ສັດສ່ວນໝວດ, ສະຕ໋ອກຕ່ຳ |
| `orders.php` | ລາຍການຄຳສັ່ງຊື້ + ກອງຕາມສະຖານະ + ຄົ້ນຫາ |
| `order_view.php` | ລາຍລະອຽດບິນ, ປ່ຽນສະຖານະ, ຢືນຢັນ/ຄືນເງິນ |
| `products.php` | ຈັດການສິນຄ້າ — ເພີ່ມ/ແກ້ໄຂ/ລຶບ (ປ້ອງກັນການລຶບສິນຄ້າທີ່ມີໃນບິນ) |
| `product_form.php` | ຟອມເພີ່ມ / ແກ້ໄຂສິນຄ້າ |
| `customers.php` | ລາຍຊື່ລູກຄ້າ + ຍອດຊື້ສະສົມ |
| `schema.php` | ໂຄງສ້າງຖານຂໍ້ມູນ (ດຶງຈາກ `information_schema`) |

---

## 2. ໂຄງສ້າງໄຟລ໌

```
shop/
├── index.php              ໜ້າຫຼັກ / ລາຍການສິນຄ້າ
├── product.php            ລາຍລະອຽດສິນຄ້າ
├── cart.php               ກະຕ່າ
├── checkout.php           ສັ່ງຊື້
├── order_success.php      ສຳເລັດ
├── orders.php             ຄຳສັ່ງຊື້ (ລູກຄ້າ)
├── order_detail.php       ລາຍລະອຽດຄຳສັ່ງຊື້
├── login.php / register.php / logout.php / profile.php
├── config/
│   └── config.php         ຕັ້ງຄ່າ DB, admin, ຂໍ້ມູນຮ້ານ
├── includes/
│   ├── db.php             PDO + helper (q_all, q_one, q_run, CSRF, ...)
│   ├── ui.php             helper ສະແດງຜົນ
│   ├── header.php / footer.php
│   └── admin.php          layout admin + ກຣາຟ SVG
├── assets/
│   ├── css/style.css      ສະໄຕລ໌ທັງໝົດ (responsive, ບໍ່ໃຊ້ CDN)
│   └── js/app.js          JS ນ້ອຍໆ (ເມນູ, qty, flash, confirm)
├── admin/
│   ├── login.php / logout.php
│   ├── index.php / orders.php / order_view.php
│   ├── products.php / product_form.php / customers.php / schema.php
└── database/
    └── shop_db.sql        schema 5 ຕາຕະລາງ + ຂໍ້ມູນຕົວຢ່າງ
```

---

## 3. ການຕິດຕັ້ງ

### ຄວາມຕ້ອງການ
- PHP **8.1+** (ມີ `pdo_mysql`, `mbstring`)
- MySQL **8** ຫຼື MariaDB **10.4+**

### ຂັ້ນຕອນ

**1) ສ້າງຖານຂໍ້ມູນ**

```bash
mysql -u root -p --default-character-set=utf8mb4 < database/shop_db.sql
```

> ⚠️ ຕ້ອງໃຊ້ `--default-character-set=utf8mb4` ເພື່ອບໍ່ໃຫ້ຂໍ້ຄວາມລາວເສຍ (ໄຟລ໌ SQL ມີ `SET NAMES utf8mb4` ໄວ້ແລ້ວ)

**2) ສ້າງຜູ້ໃຊ້ຖານຂໍ້ມູນ**

```sql
CREATE USER 'shop'@'localhost' IDENTIFIED BY 'shop1234';
GRANT ALL PRIVILEGES ON shop_db.* TO 'shop'@'localhost';
FLUSH PRIVILEGES;
```

**3) ຕັ້ງຄ່າ**

ແກ້ໄຂ `config/config.php`:

```php
const DB_HOST = '127.0.0.1';
const DB_NAME = 'shop_db';
const DB_USER = 'shop';
const DB_PASS = 'shop1234';

const ADMIN_USER = 'admin';     // ຜູ້ດູແລລະບົບ
const ADMIN_PASS = 'admin123';
```

**4) ແລ່ນ**

```bash
# ພາຍໃນເຄື່ອງ
php -S 0.0.0.0:8080 -t .

# ຫຼື ວາງໄວ້ໃນ htdocs / www ຂອງ Apache ຫຼື Nginx
```

ເປີດ `http://localhost:8080`

---

## 4. ບັນຊີທົດລອງ

| ປະເພດ | ຜູ້ໃຊ້ | ລະຫັດຜ່ານ |
|--------|--------|-----------|
| ລູກຄ້າ | `02055511111` (ຫຼື `somphone@example.com`) | `123456` |
| ລູກຄ້າ | `02055522222` | `123456` |
| ຜູ້ດູແລລະບົບ | `admin` | `admin123` |

> ລະຫັດຜ່ານລູກຄ້າເກັບດ້ວຍ `password_hash()` (bcrypt) — ບໍ່ເກັບ plain text

---

## 5. ຄວາມປອດໄພທີ່ໃຊ້

| ຄວາມສ່ຽງ | ການປ້ອງກັນ |
|----------|-----------|
| SQL Injection | **Prepared statements** (PDO) ທຸກ query |
| XSS | `htmlspecialchars()` ຜ່ານ `e()` ທຸກຈຸດທີ່ສະແດງຂໍ້ມູນ |
| CSRF | token ໃນທຸກຟອມ POST + `hash_equals()` |
| ລະຫັດຜ່ານ | `password_hash()` / `password_verify()` (bcrypt) |
| Session fixation | `session_regenerate_id(true)` ຕອນ login |
| ຂໍ້ມູນເສຍຫາຍ | ກວດສະຕ໋ອກກ່ອນສັ່ງຊື້, ໃຊ້ **transaction** ຕອນສ້າງບິນ, FK + CHECK constraints |

---

## 6. ການອອກແບບຖານຂໍ້ມູນ (5 ຕາຕະລາງ)

```
customers ──1:N──> orders ──1:N──> order_items <──N:1── products
                     └──1:N──> payments
```

| ຕາຕະລາງ | PK | FK | ໜ້າທີ່ |
|-----------|----|----|---------|
| `customers` | `customer_id` | — | ລູກຄ້າ + ບັນຊີ |
| `products` | `product_id` | — | ສິນຄ້າ (1 ແຖວ = 1 SKU) |
| `orders` | `order_id` | `customer_id` | ຫົວບິນ |
| `order_items` | `item_id` | `order_id`, `product_id` | ລາຍການໃນບິນ |
| `payments` | `payment_id` | `order_id` | ການຊຳລະ |

**ເຫດຜົນທີ່ບໍ່ມີຕາຕະລາງ admin:** ຜູ້ດູແລລະບົບຖືກຈັດການໃນ `config/config.php`
ເພື່ອຮັກສາຈຳນວນຕາຕະລາງໄວ້ **5 ຕາມກຳນົດ**.

---

## 7. ໝາຍເຫດການພັດທະນາ

- ໃຊ້ emoji ແທນຮູບພາບສິນຄ້າ ເພື່ອໃຫ້ແລ່ນໄດ້ທັນທີໂດຍບໍ່ຕ້ອງອັບໂຫຼດໄຟລ໌ (ຟິລ `image_url` ຍັງມີໃຫ້ອັບເດດ)
- ກຣາຟໃນແດຊບອດເປັນ **SVG ທີ່ສ້າງດ້ວຍ PHP** — ບໍ່ຕ້ອງອິນເຕີເນັດ / CDN
- ຟອນລາວໃຊ້ຟອນຂອງລະບົບ (`Noto Sans Lao`, `Phetsarath OT`, `Saysettha OT`) — ບໍ່ໂຫຼດຈາກ CDN
- ຮອງຮັບມືຖື (responsive) ຕັ້ງແຕ່ 360px ຂຶ້ນໄປ
