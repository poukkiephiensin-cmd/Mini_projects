<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/admin.php';
require_admin();

$q = trim((string)($_GET['q'] ?? ''));
$sql = 'SELECT c.*,
               (SELECT COUNT(*) FROM orders o WHERE o.customer_id = c.customer_id) AS order_cnt,
               (SELECT COALESCE(SUM(o.total_amount),0) FROM orders o
                 WHERE o.customer_id = c.customer_id AND o.status <> "cancelled") AS spent,
               (SELECT MAX(o.order_date) FROM orders o WHERE o.customer_id = c.customer_id) AS last_order
        FROM customers c WHERE 1=1';
$params = [];
if ($q !== '') {
    $sql .= ' AND (c.full_name LIKE ? OR c.phone LIKE ? OR c.email LIKE ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like);
}
$sql .= ' ORDER BY c.created_at DESC, c.customer_id DESC';
$customers = q_all($sql, $params);

admin_header('ລູກຄ້າ', 'customers');
?>

<div class="admin-top">
  <div>
    <h1>ລູກຄ້າ</h1>
    <div class="muted small"><?= count($customers) ?> ຄົນ</div>
  </div>
  <form method="get" style="display:flex;gap:8px">
    <input type="search" name="q" value="<?= e($q) ?>" placeholder="ຊື່, ເບີໂທ, ອີເມວ" style="min-width:240px">
    <button class="btn btn-dark btn-sm" type="submit">ຄົ້ນຫາ</button>
  </form>
</div>

<section class="card">
  <div class="table-wrap">
    <table class="data">
      <thead>
        <tr><th>#</th><th>ຊື່</th><th>ເບີໂທ</th><th>ອີເມວ</th><th>ທີ່ຢູ່</th>
            <th class="num">ຄຳສັ່ງຊື້</th><th class="num">ຍອດຊື້</th><th>ຊື້ລ່າສຸດ</th></tr>
      </thead>
      <tbody>
        <?php foreach ($customers as $c): ?>
          <tr>
            <td class="muted"><?= (int)$c['customer_id'] ?></td>
            <td>
              <strong><?= e($c['full_name']) ?></strong>
              <div class="muted small"><?= $c['gender'] === 'F' ? 'ຍິງ' : ($c['gender'] === 'M' ? 'ຊາຍ' : 'ອື່ນໆ') ?></div>
            </td>
            <td><?= e($c['phone']) ?></td>
            <td class="muted"><?= e($c['email'] ?: '—') ?></td>
            <td class="muted small"><?= e(trim(($c['address'] ?? '') . ' ' . ($c['city'] ?? '')) ?: '—') ?></td>
            <td class="num"><?= (int)$c['order_cnt'] ?></td>
            <td class="num"><strong><?= money($c['spent']) ?></strong></td>
            <td class="muted small"><?= $c['last_order'] ? date('d/m/Y', strtotime($c['last_order'])) : '—' ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$customers): ?><tr><td colspan="8" style="padding:32px;text-align:center" class="muted">ບໍ່ພົບລູກຄ້າ</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</section>

<?php admin_footer(); ?>
