<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/admin.php';
require_admin();

// ---- ຕົວເລກສະຫຼຸບ ----
$revenue   = (float)q_val("SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE status <> 'cancelled'");
$orderCnt  = (int)q_val('SELECT COUNT(*) FROM orders');
$openCnt   = (int)q_val("SELECT COUNT(*) FROM orders WHERE status IN ('pending','confirmed','packing','shipped')");
$custCnt   = (int)q_val('SELECT COUNT(*) FROM customers');
$prodCnt   = (int)q_val("SELECT COUNT(*) FROM products WHERE status = 'active'");
$lowStock  = (int)q_val('SELECT COUNT(*) FROM products WHERE stock_qty <= 5');
$avgOrder  = $orderCnt > 0 ? $revenue / $orderCnt : 0;
$unpaid    = (float)q_val("SELECT COALESCE(SUM(o.total_amount),0) FROM orders o
                           WHERE o.status <> 'cancelled' AND NOT EXISTS (
                             SELECT 1 FROM payments p WHERE p.order_id = o.order_id AND p.payment_status = 'paid')");

// ---- ຍອດຂາຍ 7 ວັນຫຼ້າສຸດ ----
$labels = [];
$values = [];
for ($i = 6; $i >= 0; $i--) {
    $day = date('Y-m-d', strtotime("-$i day"));
    $labels[] = date('d/m', strtotime($day));
    $values[] = (float)q_val(
        "SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE DATE(order_date) = ? AND status <> 'cancelled'",
        [$day]
    );
}

// ---- ຍອດຂາຍຕາມໝວດ ----
$byCat = q_all(
    "SELECT p.category, COALESCE(SUM(oi.line_total),0) AS amount, COALESCE(SUM(oi.quantity),0) AS qty
     FROM order_items oi
     JOIN products p ON p.product_id = oi.product_id
     JOIN orders o ON o.order_id = oi.order_id AND o.status <> 'cancelled'
     GROUP BY p.category ORDER BY amount DESC"
);
$catData = [];
foreach ($byCat as $r) {
    $catData[$r['category']] = (float)$r['amount'];
}

$recentOrders = q_all(
    "SELECT o.*, c.full_name,
            (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.order_id) AS line_count
     FROM orders o JOIN customers c ON c.customer_id = o.customer_id
     ORDER BY o.order_date DESC, o.order_id DESC LIMIT 8"
);

$topProducts = q_all(
    "SELECT p.product_id, p.product_name, p.category, COALESCE(SUM(oi.quantity),0) AS qty,
            COALESCE(SUM(oi.line_total),0) AS amount
     FROM products p
     LEFT JOIN order_items oi ON oi.product_id = p.product_id
     LEFT JOIN orders o ON o.order_id = oi.order_id AND o.status <> 'cancelled'
     GROUP BY p.product_id ORDER BY qty DESC, amount DESC LIMIT 6"
);

$lowList = q_all('SELECT * FROM products WHERE stock_qty <= 5 ORDER BY stock_qty ASC LIMIT 5');

admin_header('ແດຊບອດ', 'dashboard');
?>

<div class="admin-top">
  <h1>ແດຊບອດ</h1>
  <div class="muted small">ຂໍ້ມູນ ณ <?= date('d/m/Y H:i') ?></div>
</div>

<div class="stats">
  <div class="stat stat-accent">
    <div class="label">ຍອດຂາຍລວມ</div>
    <div class="value"><?= money($revenue) ?></div>
    <div class="sub"><?= $orderCnt ?> ຄຳສັ່ງຊື້ · ສະເລ່ຍ <?= money($avgOrder) ?>/ບິນ</div>
  </div>
  <div class="stat stat-ink">
    <div class="label">ຄຳສັ່ງຊື້ທີ່ຕ້ອງດຳເນີນການ</div>
    <div class="value"><?= $openCnt ?></div>
    <div class="sub"><a href="<?= e(BASE_URL) ?>/admin/orders.php">ໄປຈັດການ →</a></div>
  </div>
  <div class="stat stat-teal">
    <div class="label">ຍອດຄ້າງຊຳລະ</div>
    <div class="value" style="font-size:22px"><?= money($unpaid) ?></div>
    <div class="sub">ບິນທີ່ຍັງບໍ່ໄດ້ paid</div>
  </div>
  <div class="stat stat-gold">
    <div class="label">ລູກຄ້າ</div>
    <div class="value"><?= $custCnt ?></div>
    <div class="sub"><a href="<?= e(BASE_URL) ?>/admin/customers.php">ເບິ່ງລາຍຊື່ →</a></div>
  </div>
  <div class="stat">
    <div class="label">ສິນຄ້າຂາຍຢູ່</div>
    <div class="value"><?= $prodCnt ?></div>
    <div class="sub"><?= $lowStock ?> ລາຍການສະຕ໋ອກຕ່ຳ</div>
  </div>
</div>

<div style="display:grid;grid-template-columns:1.55fr 1fr;gap:20px;align-items:start;margin-bottom:22px" class="dash-grid">
  <section class="card">
    <div class="card-head">
      <h2>ຍອດຂາຍ 7 ວັນຫຼ້າສຸດ</h2>
      <span class="muted small">ບໍ່ລວມບິນຍົກເລີກ</span>
    </div>
    <div class="card-pad"><?= bar_chart($labels, $values) ?></div>
  </section>

  <section class="card">
    <div class="card-head"><h2>ຍອດຂາຍຕາມໝວດ</h2></div>
    <div class="card-pad" style="display:flex;gap:18px;align-items:center;flex-wrap:wrap">
      <?= donut_chart($catData) ?>
      <div style="flex:1;min-width:150px;display:grid;gap:8px;font-size:14px">
        <?php $colors = ['#b83d0a', '#0f6b5f', '#b98b24', '#7c3aed', '#0891b2', '#db2777', '#64748b']; $i = 0; ?>
        <?php foreach ($catData as $cat => $amt): ?>
          <div style="display:flex;align-items:center;gap:8px">
            <span style="width:10px;height:10px;border-radius:3px;background:<?= $colors[$i % count($colors)] ?>;flex:0 0 auto"></span>
            <span style="flex:1"><?= e($cat) ?></span>
            <strong style="font-size:13px"><?= money($amt) ?></strong>
          </div>
          <?php $i++; ?>
        <?php endforeach; ?>
        <?php if (!$catData): ?><span class="muted">ຍັງບໍ່ມີຂໍ້ມູນ</span><?php endif; ?>
      </div>
    </div>
  </section>
</div>

<section class="card" style="margin-bottom:22px">
  <div class="card-head">
    <h2>ຄຳສັ່ງຊື້ຫຼ້າສຸດ</h2>
    <a class="btn btn-outline btn-sm" href="<?= e(BASE_URL) ?>/admin/orders.php">ທັງໝົດ →</a>
  </div>
  <div class="table-wrap">
    <table class="data">
      <thead><tr><th>#</th><th>ລູກຄ້າ</th><th>ວັນທີ</th><th class="num">ລາຍການ</th><th class="num">ຍອດລວມ</th><th>ສະຖານະ</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($recentOrders as $o): ?>
          <tr>
            <td><strong>#<?= (int)$o['order_id'] ?></strong></td>
            <td><?= e($o['full_name']) ?></td>
            <td class="muted"><?= date('d/m/Y H:i', strtotime($o['order_date'])) ?></td>
            <td class="num"><?= (int)$o['line_count'] ?></td>
            <td class="num"><strong><?= money($o['total_amount']) ?></strong></td>
            <td><?= status_badge($o['status']) ?></td>
            <td class="num"><a class="btn btn-outline btn-sm" href="<?= e(BASE_URL) ?>/admin/order_view.php?id=<?= (int)$o['order_id'] ?>">ເປີດ</a></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px" class="dash-grid">
  <section class="card">
    <div class="card-head"><h2>ສິນຄ້າຂາຍດີ</h2></div>
    <div class="table-wrap">
      <table class="data">
        <thead><tr><th>ສິນຄ້າ</th><th class="num">ຂາຍໄດ້</th><th class="num">ຍອດ</th></tr></thead>
        <tbody>
          <?php foreach ($topProducts as $p): ?>
            <tr>
              <td><?= category_emoji($p['category']) ?> <?= e($p['product_name']) ?></td>
              <td class="num"><?= (int)$p['qty'] ?></td>
              <td class="num"><?= money($p['amount']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </section>

  <section class="card">
    <div class="card-head">
      <h2>ແຈ້ງເຕືອນສະຕ໋ອກຕ່ຳ</h2>
      <a class="btn btn-outline btn-sm" href="<?= e(BASE_URL) ?>/admin/products.php">ຈັດການ →</a>
    </div>
    <div class="table-wrap">
      <table class="data">
        <thead><tr><th>ສິນຄ້າ</th><th class="num">ຄົງເຫຼືອ</th><th></th></tr></thead>
        <tbody>
          <?php foreach ($lowList as $p): ?>
            <tr>
              <td><?= e($p['product_name']) ?> <span class="muted small">(<?= e($p['size'] ?: '-') ?> · <?= e($p['color'] ?: '-') ?>)</span></td>
              <td class="num">
                <span class="badge" style="color:<?= (int)$p['stock_qty'] === 0 ? '#b91c1c' : '#86550a' ?>;background:<?= (int)$p['stock_qty'] === 0 ? '#fee2e2' : '#fffbeb' ?>">
                  <?= (int)$p['stock_qty'] ?>
                </span>
              </td>
              <td class="num"><a class="btn btn-ghost btn-sm" href="<?= e(BASE_URL) ?>/admin/product_form.php?id=<?= (int)$p['product_id'] ?>">ແກ້ໄຂ</a></td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$lowList): ?><tr><td colspan="3" class="muted">ທຸກລາຍການມີສະຕ໋ອກພຽງພໍ ✓</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </section>
</div>

<style>@media(max-width:980px){.dash-grid{grid-template-columns:1fr !important}}</style>
<?php admin_footer(); ?>
