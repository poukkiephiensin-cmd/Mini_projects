<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $u = trim((string)($_POST['username'] ?? ''));
    $p = (string)($_POST['password'] ?? '');
    // ຜູ້ດູແລລະບົບ ເກັບໃນ config (ຮັກສາໃຫ້ມີ 5 ຕາຕະລາງ)
    if ($u === ADMIN_USER && hash_equals(ADMIN_PASS, $p)) {
        session_regenerate_id(true);
        $_SESSION['is_admin'] = true;
        $_SESSION['admin_user'] = $u;
        flash('success', 'ເຂົ້າສູ່ລະບົບຜູ້ດູແລລະບົບແລ້ວ.');
        redirect('admin/index.php');
    }
    $errors[] = 'ຊື່ຜູ້ໃຊ້ ຫຼື ລະຫັດຜ່ານ ບໍ່ຖືກຕ້ອງ.';
}
$flashes = take_flashes();
?>
<!doctype html>
<html lang="lo">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ເຂົ້າສູ່ລະບົບ — ຜູ້ດູແລລະບົບ</title>
<link rel="stylesheet" href="<?= e(BASE_URL) ?>/assets/css/style.css">
</head>
<body>
<div class="wrap">
  <div class="auth-wrap">
    <div class="auth-logo">
      <span class="brand-mark" style="width:56px;height:56px;font-size:27px;border-radius:16px">ສ</span>
    </div>
    <div class="auth-card">
      <h1>ຜູ້ດູແລລະບົບ</h1>
      <p class="auth-sub">ສິລປະ ບູຕິກ · ຈັດການສິນຄ້າ ແລະ ຄຳສັ່ງຊື້</p>

      <?php foreach ($flashes as $f): ?>
        <div class="flash flash-<?= e($f['type']) ?>" style="margin-bottom:16px"><?= e($f['msg']) ?></div>
      <?php endforeach; ?>

      <?php if ($errors): ?>
        <div class="flash flash-error" style="margin-bottom:16px">
          <?php foreach ($errors as $er): ?><div><?= e($er) ?></div><?php endforeach; ?>
        </div>
      <?php endif; ?>

      <form method="post" class="form-grid">
        <?= csrf_field() ?>
        <div class="field">
          <label for="username">ຊື່ຜູ້ໃຊ້</label>
          <input id="username" type="text" name="username" required autofocus autocomplete="username">
        </div>
        <div class="field">
          <label for="password">ລະຫັດຜ່ານ</label>
          <input id="password" type="password" name="password" required autocomplete="current-password">
        </div>
        <button class="btn btn-dark btn-block btn-lg" type="submit">ເຂົ້າສູ່ລະບົບ</button>
      </form>

      <div class="flash flash-info" style="margin-top:18px;font-size:13.5px">
        <strong>ບັນຊີເລີ່ມຕົ້ນ:</strong> <code><?= e(ADMIN_USER) ?></code> / <code><?= e(ADMIN_PASS) ?></code>
        <br>ແກ້ໄຂໄດ້ໃນ <code>config/config.php</code>
      </div>

      <p class="auth-foot"><a href="<?= e(BASE_URL) ?>/index.php">← ກັບໜ້າຮ້ານ</a></p>
    </div>
  </div>
</div>
</body>
</html>
