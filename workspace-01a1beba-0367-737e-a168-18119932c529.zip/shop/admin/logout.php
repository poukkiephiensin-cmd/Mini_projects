<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
unset($_SESSION['is_admin'], $_SESSION['admin_user']);
flash('info', 'ອອກຈາກລະບົບຜູ້ດູແລລະບົບແລ້ວ.');
redirect('admin/login.php');
