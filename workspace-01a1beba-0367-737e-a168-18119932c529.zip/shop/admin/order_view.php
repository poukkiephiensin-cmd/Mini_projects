<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/admin.php';
require_admin();

$id = (int)($_GET['id'] ?? 0);

// ---- ອັບເດດສະຖານະ ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $action = (string)($_POST['action'] ?? '');
    $allowed = ['pending', 'confirmed', 'packing', 'shipped', 'delivered', 'cancelled'];

    if ($action === 'status') {
        $new = (string)($_POST['status'] ?? '');
        if (!in_array($new, $allowed, true)) {
            flash('error', 'ສະຖານະບໍ່ຖືກຕ້ອງ.');
        } else {
            q_run('UPDATE orders SET status = ? WHERE order_id = ?', [$new, $id]);
            flash('success', 'ປ່ຽນສະຖານະເປັນ “' . status_label($new)[0] . '” ແລ້ວ.');
        }
        redirect('admin/order_view.php', ['id' => $id]);
    }

    if ($action === 'payment') {
        $pid  = (int)($_POST['payment_id'] ?? 0);
        $stat = (string)($_POST['payment_status'] ?? '');
        if (in_array($stat, ['pending', 'paid', 'failed', 'refunded'], true)) {
            if ($stat === 'paid') {
                q_run("UPDATE payments SET payment_status = 'paid', paid_at = NOW() WHERE payment_id = ? AND order_id = ?", [$pid, $id]);
                // ຖ້າຈ່າຍແລ້ວ ແລະ ບິນຍັງ pending → ຢືນຢັນ
                q_run("UPDATE orders SET status = 'confirmed' WHERE order_id = ? AND status = 'pending'", [$id]);
            } else {
                q_run('UPDATE payments SET payment_status = ?, paid_at = NULL WHERE payment_id = ? AND order_id = ?', [$stat, $pid, $id]);
            }
            flash('success', 'ອັບເດດການຊຳລະແລ້ວ.');
        }
        redirect('admin/order_view.php', ['id' => $id]);
    }
}

$order = q_one(
    'SELECT o.*, c.full_name, c.phone, c.email, c.address, c.city
     FROM orders o JOIN customers c ON c.customer_id = o.customer_id
     WHERE o.order_id = ?',
    [$id]
);

if (!$order) {
    flash('error', 'ບໍ່ພົບຄຳສັ່ງຊື້ #' . $id);
    redirect('admin/orders.php');
}

$items = q_all(
    'SELECT oi.*, p.product_name, p.category, p.stock_qty
     FROM order_items oi JOIN products p ON p.product_id = oi.product_id
     WHERE oi.order_id = ? ORDER BY oi.item_id',
    [$id]
);
$payments = q_all('SELECT * FROM payments WHERE order_id = ? ORDER BY payment_id DESC', [$id]);
$steps = order_status_steps($order['status']);

admin_header('ຄຳສັ່ງຊື້ #' . $id, 'orders');
?>

<div class="admin-top">
  <div>
    <a class="muted small" href="<?= e(BASE_URL) ?>/admin/orders.php">← ກັບລາຍຊື່ຄຳສັ່ງຊື້</a>
    <h1 style="margin-top:6px">ຄຳສັ່ງຊື້ #<?= (int)$order['order_id'] ?> <?= status_badge($order['status']) ?></h1>
    <div class="muted small">ສັ່ງເມື່ອ <?= date('d/m/Y H:i', strtotime($order['order_date'])) ?></div>
  </div>
  <form method="post" style="display:flex;gap:8px;align-items:center">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="status">
    <select name="status" style="min-width:180px">
      <?php foreach ($statuses = ['pending', 'confirmed', 'packing', 'shipped', 'delivered', 'cancelled'] as $s): ?>
        <option value="<?= e($s) ?>" <?= $order['status'] === $s ? 'selected' : '' ?>><?= e(status_label($s)[0]) ?></option>
      <?php endforeach; ?>
    </select>
    <button class="btn btn-dark btn-sm" type="submit">ບັນທຶກສະຖານະ</button>
  </form>
</div>

<div class="timeline" style="margin-bottom:22px">
  <?php foreach ($steps as [$label, $done]): ?>
    <div class="tl-step <?= $done ? 'done' : '' ?>"><?= e($label) ?></div>
  <?php endforeach; ?>
</div>

<div class="detail-grid">
  <div style="display:grid;gap:20px">
    <section class="card">
      <div class="card-head"><h2>ລາຍການສິນຄ້າ</h2></div>
      <div class="table-wrap">
        <table class="data">
          <thead><tr><th>ສິນຄ້າ</th><th>ຂະໜາດ/ສີ</th><th class="num">ຈຳນວນ</th><th class="num">ລາຄາ</th><th class="num">ລວມ</th></tr></thead>
          <tbody>
            <?php foreach ($items as $it): ?>
              <tr>
                <td>
                  <?= category_emoji($it['category']) ?> <?= e($it['product_name']) ?>
                  <div class="muted small">ສະຕ໋ອກປັດຈຸບັນ: <?= (int)$it['stock_qty'] ?></div>
                </td>
                <td class="muted"><?= e($it['size'] ?: '-') ?> / <?= e($it['color'] ?: '-') ?></td>
                <td class="num"><?= (int)$it['quantity'] ?></td>
                <td class="num"><?= money($it['unit_price']) ?></td>
                <td class="num"><strong><?= money($it['line_total']) ?></strong></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
          <tfoot>
            <tr><td colspan="4" class="num">ລວມຄ່າສິນຄ້າ</td><td class="num"><?= money($order['subtotal']) ?></td></tr>
            <tr><td colspan="4" class="num">ຄ່າຂົນສົ່ງ</td><td class="num"><?= money($order['shipping_fee']) ?></td></tr>
            <tr><td colspan="4" class="num">ສ່ວນຫຼຸດ</td><td class="num">−<?= money($order['discount']) ?></td></tr>
            <tr><td colspan="4" class="num">ຍອດລວມ</td><td class="num"><?= money($order['total_amount']) ?></td></tr>
          </tfoot>
        </table>
      </div>
    </section>

    <section class="card">
      <div class="card-head"><h2>ການຊຳລະ</h2></div>
      <div class="table-wrap">
        <table class="data">
          <thead><tr><th>ຊ່ອງທາງ</th><th class="num">ຈຳນວນ</th><th>ສະຖານະ</th><th>ອ້າງອີງ</th><th>ວັນຈ່າຍ</th><th></th></tr></thead>
          <tbody>
            <?php foreach ($payments as $pm): ?>
              <tr>
                <td><?= e(payment_label($pm['payment_method'])) ?></td>
                <td class="num"><?= money($pm['amount']) ?></td>
                <td><?= status_badge($pm['payment_status']) ?></td>
                <td class="muted small"><?= e($pm['transaction_ref'] ?: '—') ?></td>
                <td class="muted small"><?= $pm['paid_at'] ? date('d/m/Y H:i', strtotime($pm['paid_at'])) : '—' ?></td>
                <td>
                  <div class="row-actions">
                    <?php if ($pm['payment_status'] !== 'paid'): ?>
                      <form method="post">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="payment">
                        <input type="hidden" name="payment_id" value="<?= (int)$pm['payment_id'] ?>">
                        <input type="hidden" name="payment_status" value="paid">
                        <button class="btn btn-primary btn-sm" type="submit">ຢືນຢັນຈ່າຍ</button>
                      </form>
                    <?php endif; ?>
                    <?php if ($pm['payment_status'] === 'paid'): ?>
                      <form method="post" data-confirm="ການຄືນເງິນຈະປ່ຽນສະຖານະເປັນ refunded — ຢືນຢັນ?">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="payment">
                        <input type="hidden" name="payment_id" value="<?= (int)$pm['payment_id'] ?>">
                        <input type="hidden" name="payment_status" value="refunded">
                        <button class="btn btn-outline btn-sm" type="submit">ຄືນເງິນ</button>
                      </form>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
            <?php if (!$payments): ?><tr><td colspan="6" class="muted">ຍັງບໍ່ມີລາຍການຊຳລະ</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </section>
  </div>

  <aside style="display:grid;gap:18px">
    <div class="card card-pad">
      <h3 style="font-size:16px">ລູກຄ້າ</h3>
      <dl class="kv">
        <dt>ຊື່</dt><dd><?= e($order['full_name']) ?></dd>
        <dt>ເບີໂທ</dt><dd><?= e($order['phone']) ?></dd>
        <dt>ອີເມວ</dt><dd><?= e($order['email'] ?: '—') ?></dd>
        <dt>ລະຫັດ</dt><dd><a href="<?= e(BASE_URL) ?>/admin/customers.php?q=<?= urlencode($order['phone']) ?>">ເບິ່ງໂປຣໄຟລ໌ →</a></dd>
      </dl>
    </div>
    <div class="card card-pad">
      <h3 style="font-size:16px">ການຈັດສົ່ງ</h3>
      <dl class="kv">
        <dt>ທີ່ຢູ່</dt><dd><?= e($order['shipping_address']) ?></dd>
        <?php if ($order['note']): ?><dt>ໝາຍເຫດ</dt><dd><?= e($order['note']) ?></dd><?php endif; ?>
      </dl>
    </div>
  </aside>
</div>

<?php admin_footer(); ?>
