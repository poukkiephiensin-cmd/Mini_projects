<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/admin.php';
require_admin();

$statuses = ['pending', 'confirmed', 'packing', 'shipped', 'delivered', 'cancelled'];
$status   = (string)($_GET['status'] ?? '');
$q        = trim((string)($_GET['q'] ?? ''));

$sql = 'SELECT o.*, c.full_name, c.phone,
               (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.order_id) AS line_count,
               (SELECT p.payment_status FROM payments p WHERE p.order_id = o.order_id ORDER BY p.payment_id DESC LIMIT 1) AS pay_status
        FROM orders o JOIN customers c ON c.customer_id = o.customer_id WHERE 1=1';
$params = [];

if (in_array($status, $statuses, true)) {
    $sql .= ' AND o.status = ?';
    $params[] = $status;
}
if ($q !== '') {
    $sql .= ' AND (c.full_name LIKE ? OR c.phone LIKE ? OR o.order_id = ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like, (int)$q);
}
$sql .= ' ORDER BY o.order_date DESC, o.order_id DESC';
$orders = q_all($sql, $params);

$counts = [];
foreach (q_all('SELECT status, COUNT(*) c FROM orders GROUP BY status') as $r) {
    $counts[$r['status']] = (int)$r['c'];
}
$total = array_sum($counts);

admin_header('ຄຳສັ່ງຊື້', 'orders');
?>

<div class="admin-top">
  <h1>ຄຳສັ່ງຊື້</h1>
  <form method="get" style="display:flex;gap:8px">
    <?php if ($status !== ''): ?><input type="hidden" name="status" value="<?= e($status) ?>"><?php endif; ?>
    <input type="search" name="q" value="<?= e($q) ?>" placeholder="ຄົ້ນຫາ: ຊື່, ເບີໂທ, ເລກບິນ" style="min-width:250px">
    <button class="btn btn-dark btn-sm" type="submit">ຄົ້ນຫາ</button>
  </form>
</div>

<div class="chips">
  <a class="chip <?= $status === '' ? 'active' : '' ?>" href="<?= e(BASE_URL) ?>/admin/orders.php">ທັງໝົດ (<?= $total ?>)</a>
  <?php foreach ($statuses as $s): ?>
    <a class="chip <?= $status === $s ? 'active' : '' ?>" href="<?= e(BASE_URL) ?>/admin/orders.php?status=<?= e($s) ?>">
      <?= e(status_label($s)[0]) ?> (<?= $counts[$s] ?? 0 ?>)
    </a>
  <?php endforeach; ?>
</div>

<section class="card">
  <div class="table-wrap">
    <table class="data">
      <thead>
        <tr>
          <th>#</th><th>ລູກຄ້າ</th><th>ວັນທີ</th><th class="num">ລາຍການ</th>
          <th class="num">ຍອດລວມ</th><th>ການຊຳລະ</th><th>ສະຖານະ</th><th></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($orders as $o): ?>
          <tr>
            <td><strong>#<?= (int)$o['order_id'] ?></strong></td>
            <td>
              <div><?= e($o['full_name']) ?></div>
              <div class="muted small"><?= e($o['phone']) ?></div>
            </td>
            <td class="muted"><?= date('d/m/Y H:i', strtotime($o['order_date'])) ?></td>
            <td class="num"><?= (int)$o['line_count'] ?></td>
            <td class="num"><strong><?= money($o['total_amount']) ?></strong></td>
            <td><?= $o['pay_status'] ? status_badge($o['pay_status']) : '<span class="muted small">—</span>' ?></td>
            <td><?= status_badge($o['status']) ?></td>
            <td class="num">
              <a class="btn btn-outline btn-sm" href="<?= e(BASE_URL) ?>/admin/order_view.php?id=<?= (int)$o['order_id'] ?>">ເປີດ</a>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$orders): ?>
          <tr><td colspan="8" class="muted" style="padding:32px;text-align:center">ບໍ່ພົບຄຳສັ່ງຊື້</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</section>

<?php admin_footer(); ?>
