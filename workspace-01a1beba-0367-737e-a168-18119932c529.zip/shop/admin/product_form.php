<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/admin.php';
require_admin();

$id = (int)($_GET['id'] ?? 0);
$isEdit = $id > 0;
$errors = [];

$p = [
    'product_id'  => 0,
    'product_name' => '',
    'category'    => 'ເສື້ອ',
    'brand'       => '',
    'size'        => '',
    'color'       => '',
    'description' => '',
    'price'       => '',
    'cost_price'  => '',
    'stock_qty'   => 0,
    'image_url'   => '',
    'status'      => 'active',
];

if ($isEdit) {
    $found = q_one('SELECT * FROM products WHERE product_id = ?', [$id]);
    if (!$found) {
        flash('error', 'ບໍ່ພົບສິນຄ້າ #' . $id);
        redirect('admin/products.php');
    }
    $p = $found;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    foreach (['product_name', 'category', 'brand', 'size', 'color', 'description', 'image_url', 'status'] as $k) {
        $p[$k] = trim((string)($_POST[$k] ?? ''));
    }
    $p['price']      = (string)($_POST['price'] ?? '0');
    $p['cost_price'] = (string)($_POST['cost_price'] ?? '');
    $p['stock_qty']  = (int)($_POST['stock_qty'] ?? 0);

    if (mb_strlen($p['product_name']) < 3) {
        $errors[] = 'ກະລຸນາໃສ່ຊື່ສິນຄ້າ (ຢ່າງໜ້ອຍ 3 ຕົວອັກສອນ).';
    }
    if ($p['category'] === '') {
        $errors[] = 'ກະລຸນາເລືອກໝວດ.';
    }
    if (!is_numeric($p['price']) || (float)$p['price'] < 0) {
        $errors[] = 'ລາຄາຕ້ອງເປັນຕົວເລກ ແລະ ບໍ່ຕິດລົບ.';
    }
    if ($p['cost_price'] !== '' && (!is_numeric($p['cost_price']) || (float)$p['cost_price'] < 0)) {
        $errors[] = 'ລາຄາຕົ້ນທຶນບໍ່ຖືກຕ້ອງ.';
    }
    if ($p['stock_qty'] < 0) {
        $errors[] = 'ຈຳນວນສະຕ໋ອກບໍ່ຕິດລົບ.';
    }
    if (!in_array($p['status'], ['active', 'inactive', 'out_of_stock'], true)) {
        $p['status'] = 'active';
    }
    // ປັບສະຖານະອັດຕະໂນມັດ
    if ($p['status'] === 'active' && $p['stock_qty'] <= 0) {
        $p['status'] = 'out_of_stock';
    }
    if ($p['status'] === 'out_of_stock' && $p['stock_qty'] > 0) {
        $p['status'] = 'active';
    }

    if (!$errors) {
        $vals = [
            $p['product_name'], $p['category'],
            $p['brand'] !== '' ? $p['brand'] : null,
            $p['size'] !== '' ? $p['size'] : null,
            $p['color'] !== '' ? $p['color'] : null,
            $p['description'] !== '' ? $p['description'] : null,
            (float)$p['price'],
            $p['cost_price'] !== '' ? (float)$p['cost_price'] : null,
            $p['stock_qty'],
            $p['image_url'] !== '' ? $p['image_url'] : null,
            $p['status'],
        ];
        try {
            if ($isEdit) {
                q_run(
                    'UPDATE products SET product_name=?, category=?, brand=?, size=?, color=?, description=?,
                     price=?, cost_price=?, stock_qty=?, image_url=?, status=? WHERE product_id=?',
                    array_merge($vals, [$id])
                );
                flash('success', 'ບັນທຶກການແກ້ໄຂສິນຄ້າແລ້ວ.');
            } else {
                q_run(
                    'INSERT INTO products (product_name, category, brand, size, color, description,
                     price, cost_price, stock_qty, image_url, status)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?)',
                    $vals
                );
                flash('success', 'ເພີ່ມສິນຄ້າໃໝ່ແລ້ວ.');
            }
            redirect('admin/products.php');
        } catch (PDOException $ex) {
            $errors[] = 'ບັນທຶກບໍ່ສຳເລັດ: ' . $ex->getMessage();
        }
    }
}

$cats = ['ເສື້ອ', 'ສິ້ນ', 'ໂສ້ງ', 'ໝວກ', 'ເກີບ', 'ກະເປົ໋າ', 'ເຄື່ອງປະດັບ'];

admin_header($isEdit ? 'ແກ້ໄຂສິນຄ້າ' : 'ເພີ່ມສິນຄ້າ', 'products');
?>

<div class="admin-top">
  <div>
    <a class="muted small" href="<?= e(BASE_URL) ?>/admin/products.php">← ກັບລາຍຊື່ສິນຄ້າ</a>
    <h1 style="margin-top:6px"><?= $isEdit ? 'ແກ້ໄຂສິນຄ້າ #' . $id : 'ເພີ່ມສິນຄ້າໃໝ່' ?></h1>
  </div>
</div>

<?php if ($errors): ?>
  <div class="flash flash-error" style="margin-bottom:18px">
    <?php foreach ($errors as $er): ?><div>• <?= e($er) ?></div><?php endforeach; ?>
  </div>
<?php endif; ?>

<form method="post" class="card" style="max-width:880px">
  <?= csrf_field() ?>
  <div class="card-pad form-grid">
    <div class="field">
      <label for="product_name">ຊື່ສິນຄ້າ <span style="color:#b91c1c">*</span></label>
      <input id="product_name" type="text" name="product_name" value="<?= e($p['product_name']) ?>" required>
    </div>

    <div class="form-row">
      <div class="field">
        <label for="category">ໝວດ <span style="color:#b91c1c">*</span></label>
        <select id="category" name="category" required>
          <?php foreach ($cats as $c): ?>
            <option value="<?= e($c) ?>" <?= $p['category'] === $c ? 'selected' : '' ?>><?= category_emoji($c) ?> <?= e($c) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field">
        <label for="brand">ຍີ່ຫໍ້</label>
        <input id="brand" type="text" name="brand" value="<?= e($p['brand'] ?? '') ?>">
      </div>
    </div>

    <div class="form-row">
      <div class="field">
        <label for="size">ຂະໜາດ</label>
        <input id="size" type="text" name="size" value="<?= e($p['size'] ?? '') ?>" placeholder="S / M / L / XL / 32 / Free">
      </div>
      <div class="field">
        <label for="color">ສີ</label>
        <input id="color" type="text" name="color" value="<?= e($p['color'] ?? '') ?>" placeholder="ດຳ / ຂາວ / ແດງ">
      </div>
    </div>

    <div class="field">
      <label for="description">ລາຍລະອຽດ</label>
      <textarea id="description" name="description" placeholder="ວັດສະດຸ, ວິທີຊັກ, ຂໍ້ມູນເພີ່ມເຕີມ"><?= e($p['description'] ?? '') ?></textarea>
    </div>

    <div class="form-row">
      <div class="field">
        <label for="price">ລາຄາຂາຍ (ກີບ) <span style="color:#b91c1c">*</span></label>
        <input id="price" type="number" name="price" min="0" step="1000" value="<?= e((string)$p['price']) ?>" required>
      </div>
      <div class="field">
        <label for="cost_price">ລາຄາຕົ້ນທຶນ (ກີບ)</label>
        <input id="cost_price" type="number" name="cost_price" min="0" step="1000" value="<?= e((string)($p['cost_price'] ?? '')) ?>">
        <span class="hint">ໃຊ້ຄິດໄລ່ກຳໄລ</span>
      </div>
    </div>

    <div class="form-row">
      <div class="field">
        <label for="stock_qty">ຈຳນວນໃນສະຕ໋ອກ <span style="color:#b91c1c">*</span></label>
        <input id="stock_qty" type="number" name="stock_qty" min="0" value="<?= (int)$p['stock_qty'] ?>" required>
      </div>
      <div class="field">
        <label for="status">ສະຖານະ</label>
        <select id="status" name="status">
          <option value="active" <?= $p['status'] === 'active' ? 'selected' : '' ?>>ຂາຍຢູ່</option>
          <option value="inactive" <?= $p['status'] === 'inactive' ? 'selected' : '' ?>>ປິດຂາຍ</option>
          <option value="out_of_stock" <?= $p['status'] === 'out_of_stock' ? 'selected' : '' ?>>ໝົດສະຕ໋ອກ</option>
        </select>
      </div>
    </div>

    <div class="field">
      <label for="image_url">ລິ້ງຮູບພາບ</label>
      <input id="image_url" type="text" name="image_url" value="<?= e($p['image_url'] ?? '') ?>" placeholder="https://...">
      <span class="hint">ບໍ່ບັງຄັບ — ຖ້າບໍ່ມີ ລະບົບຈະສະແດງໄອຄອນຕາມໝວດ</span>
    </div>

    <div class="form-actions">
      <button class="btn btn-primary" type="submit"><?= $isEdit ? 'ບັນທຶກການແກ້ໄຂ' : 'ເພີ່ມສິນຄ້າ' ?></button>
      <a class="btn btn-ghost" href="<?= e(BASE_URL) ?>/admin/products.php">ຍົກເລີກ</a>
    </div>
  </div>
</form>

<?php admin_footer(); ?>
