<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/admin.php';
require_admin();

// ---- ລຶບ / ປ່ຽນສະຖານະ ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $action = (string)($_POST['action'] ?? '');
    $pid = (int)($_POST['product_id'] ?? 0);

    if ($action === 'delete' && $pid > 0) {
        $used = (int)q_val('SELECT COUNT(*) FROM order_items WHERE product_id = ?', [$pid]);
        if ($used > 0) {
            flash('error', 'ລຶບບໍ່ໄດ້ — ສິນຄ້ານີ້ມີໃນ ' . $used . ' ລາຍການສັ່ງຊື້. ປ່ຽນເປັນ “ປິດຂາຍ” ແທນ.');
        } else {
            q_run('DELETE FROM products WHERE product_id = ?', [$pid]);
            flash('success', 'ລຶບສິນຄ້າແລ້ວ.');
        }
        redirect('admin/products.php');
    }

    if ($action === 'toggle' && $pid > 0) {
        $p = q_one('SELECT status, stock_qty FROM products WHERE product_id = ?', [$pid]);
        if ($p) {
            $new = $p['status'] === 'inactive' ? ((int)$p['stock_qty'] > 0 ? 'active' : 'out_of_stock') : 'inactive';
            q_run('UPDATE products SET status = ? WHERE product_id = ?', [$new, $pid]);
            flash('success', 'ປ່ຽນສະຖານະເປັນ “' . status_label($new)[0] . '” ແລ້ວ.');
        }
        redirect('admin/products.php');
    }
}

$q   = trim((string)($_GET['q'] ?? ''));
$cat = (string)($_GET['cat'] ?? '');

$sql = 'SELECT * FROM products WHERE 1=1';
$params = [];
if ($q !== '') {
    $sql .= ' AND (product_name LIKE ? OR brand LIKE ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like);
}
if ($cat !== '') {
    $sql .= ' AND category = ?';
    $params[] = $cat;
}
$sql .= ' ORDER BY product_id DESC';
$products = q_all($sql, $params);
$categories = q_all('SELECT category, COUNT(*) c FROM products GROUP BY category ORDER BY c DESC');

admin_header('ສິນຄ້າ', 'products');
?>

<div class="admin-top">
  <div>
    <h1>ສິນຄ້າ</h1>
    <div class="muted small"><?= count($products) ?> ລາຍການ</div>
  </div>
  <div style="display:flex;gap:10px;flex-wrap:wrap">
    <form method="get" style="display:flex;gap:8px">
      <?php if ($cat !== ''): ?><input type="hidden" name="cat" value="<?= e($cat) ?>"><?php endif; ?>
      <input type="search" name="q" value="<?= e($q) ?>" placeholder="ຊື່ ຫຼື ຍີ່ຫໍ້" style="min-width:210px">
      <button class="btn btn-dark btn-sm" type="submit">ຄົ້ນຫາ</button>
    </form>
    <a class="btn btn-primary btn-sm" href="<?= e(BASE_URL) ?>/admin/product_form.php">+ ເພີ່ມສິນຄ້າ</a>
  </div>
</div>

<div class="chips">
  <a class="chip <?= $cat === '' ? 'active' : '' ?>" href="<?= e(BASE_URL) ?>/admin/products.php<?= $q !== '' ? '?q=' . urlencode($q) : '' ?>">ທັງໝົດ</a>
  <?php foreach ($categories as $c): ?>
    <a class="chip <?= $cat === $c['category'] ? 'active' : '' ?>" href="<?= e(BASE_URL) ?>/admin/products.php?cat=<?= urlencode($c['category']) ?>">
      <?= e($c['category']) ?> (<?= (int)$c['c'] ?>)
    </a>
  <?php endforeach; ?>
</div>

<section class="card">
  <div class="table-wrap">
    <table class="data">
      <thead>
        <tr><th>ສິນຄ້າ</th><th>ໝວດ</th><th>ຂະໜາດ/ສີ</th>
          <th class="num">ລາຄາ</th><th class="num">ຕົ້ນທຶນ</th><th class="num">ສະຕ໋ອກ</th><th>ສະຖານະ</th><th></th></tr>
      </thead>
      <tbody>
        <?php foreach ($products as $p): ?>
          <tr>
            <td>
              <strong><?= category_emoji($p['category']) ?> <?= e($p['product_name']) ?></strong>
              <?php if ($p['brand']): ?><div class="muted small"><?= e($p['brand']) ?></div><?php endif; ?>
            </td>
            <td class="muted"><?= e($p['category']) ?></td>
            <td class="muted"><?= e($p['size'] ?: '-') ?> / <?= e($p['color'] ?: '-') ?></td>
            <td class="num"><strong><?= money($p['price']) ?></strong></td>
            <td class="num muted"><?= money($p['cost_price']) ?></td>
            <td class="num">
              <span class="badge" style="color:<?= (int)$p['stock_qty'] === 0 ? '#b91c1c' : ((int)$p['stock_qty'] <= 5 ? '#86550a' : '#047857') ?>;background:<?= (int)$p['stock_qty'] === 0 ? '#fee2e2' : ((int)$p['stock_qty'] <= 5 ? '#fffbeb' : '#d1fae5') ?>">
                <?= (int)$p['stock_qty'] ?>
              </span>
            </td>
            <td><?= status_badge($p['status']) ?></td>
            <td>
              <div class="row-actions">
                <a class="btn btn-outline btn-sm" href="<?= e(BASE_URL) ?>/admin/product_form.php?id=<?= (int)$p['product_id'] ?>">ແກ້ໄຂ</a>
                <form method="post">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="toggle">
                  <input type="hidden" name="product_id" value="<?= (int)$p['product_id'] ?>">
                  <button class="btn btn-ghost btn-sm" type="submit"><?= $p['status'] === 'inactive' ? 'ເປີດຂາຍ' : 'ປິດຂາຍ' ?></button>
                </form>
                <form method="post" data-confirm="ລຶບສິນຄ້ານີ້ຖາວອນ?">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="product_id" value="<?= (int)$p['product_id'] ?>">
                  <button class="btn btn-ghost btn-sm" type="submit" style="color:#b91c1c">ລຶບ</button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$products): ?><tr><td colspan="8" style="padding:32px;text-align:center" class="muted">ບໍ່ພົບສິນຄ້າ</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</section>

<?php admin_footer(); ?>
