<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/admin.php';
require_admin();

/** ຄຳອະທິບາຍຕາຕະລາງ */
$tableInfo = [
    'customers' => [
        'label' => 'ລູກຄ້າ',
        'color' => '#2563eb',
        'desc'  => 'ເກັບຂໍ້ມູນລູກຄ້າ ແລະ ບັນຊີເຂົ້າໃຊ້',
    ],
    'products' => [
        'label' => 'ສິນຄ້າ',
        'color' => '#059669',
        'desc'  => 'ເກັບສິນຄ້າເສື້ອຜ້າ, ລາຄາ ແລະ ສະຕ໋ອກ (1 ແຖວ = 1 SKU)',
    ],
    'orders' => [
        'label' => 'ຄຳສັ່ງຊື້',
        'color' => '#7c3aed',
        'desc'  => 'ຫົວບິນ / ຄຳສັ່ງຊື້ ຂອງລູກຄ້າແຕ່ລະຄັ້ງ',
    ],
    'order_items' => [
        'label' => 'ລາຍລະອຽດຄຳສັ່ງຊື້',
        'color' => '#d97706',
        'desc'  => 'ສິນຄ້າແຕ່ລະລາຍການໃນບິນ',
    ],
    'payments' => [
        'label' => 'ການຊຳລະເງິນ',
        'color' => '#db2777',
        'desc'  => 'ປະຫວັດການຈ່າຍເງິນຂອງແຕ່ລະບິນ',
    ],
];

$tables = [];
foreach ($tableInfo as $name => $meta) {
    $cols = q_all('SHOW FULL COLUMNS FROM `' . $name . '`');
    $rowCnt = (int)q_val('SELECT COUNT(*) FROM `' . $name . '`');
    $fks = q_all(
        'SELECT COLUMN_NAME, REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME
         FROM information_schema.KEY_COLUMN_USAGE
         WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND REFERENCED_TABLE_NAME IS NOT NULL',
        [DB_NAME, $name]
    );
    $tables[$name] = $meta + ['cols' => $cols, 'rows' => $rowCnt, 'fks' => $fks];
}

$fkMap = [];
foreach ($tables as $tn => $t) {
    foreach ($t['fks'] as $fk) {
        $fkMap[$tn . '.' . $fk['COLUMN_NAME']] = $fk['REFERENCED_TABLE_NAME'] . '.' . $fk['REFERENCED_COLUMN_NAME'];
    }
}

admin_header('ໂຄງສ້າງຖານຂໍ້ມູນ', 'schema');
?>

<div class="admin-top">
  <div>
    <h1>ໂຄງສ້າງຖານຂໍ້ມູນ</h1>
    <div class="muted small">ຖານຂໍ້ມູນ <code><?= e(DB_NAME) ?></code> · 5 ຕາຕະລາງ</div>
  </div>
  <div class="muted small">MySQL / MariaDB · utf8mb4</div>
</div>

<div class="stats" style="margin-bottom:24px">
  <?php foreach ($tables as $tn => $t): ?>
    <div class="stat" style="border-left:4px solid <?= e($t['color']) ?>">
      <div class="label"><?= e($t['label']) ?></div>
      <div class="value" style="font-size:19px;font-family:ui-monospace,Menlo,monospace"><?= e($tn) ?></div>
      <div class="sub"><?= count($t['cols']) ?> ຄໍລຳ · <?= number_format($t['rows']) ?> ແຖວ</div>
    </div>
  <?php endforeach; ?>
</div>

<?php if ($tables): ?>
  <section class="card" style="margin-bottom:26px">
    <div class="card-head"><h2>ຄວາມສຳພັນ (ER)</h2></div>
    <div class="card-pad">
      <div style="display:grid;gap:10px;font-size:14.5px">
        <div>🟦 <code>customers</code> <strong>1 → N</strong> 🟪 <code>orders</code> <span class="muted">— ລູກຄ້າ 1 ຄົນ ມີຫຼາຍຄຳສັ່ງຊື້</span></div>
        <div>🟪 <code>orders</code> <strong>1 → N</strong> 🟧 <code>order_items</code> <span class="muted">— ບິນ 1 ໃບ ມີຫຼາຍລາຍການ</span></div>
        <div>🟩 <code>products</code> <strong>1 → N</strong> 🟧 <code>order_items</code> <span class="muted">— ສິນຄ້າ 1 ຊະນິດ ຖືກສັ່ງຫຼາຍຄັ້ງ</span></div>
        <div>🟪 <code>orders</code> <strong>1 → N</strong> 🟥 <code>payments</code> <span class="muted">— ບິນ 1 ໃບ ອາດມີຫຼາຍການຊຳລະ</span></div>
      </div>
    </div>
  </section>
<?php endif; ?>

<?php foreach ($tables as $tn => $t): ?>
  <section class="sql-table" style="box-shadow:var(--shadow)">
    <div class="sql-head" style="background:#15171c">
      <span class="dot" style="background:<?= e($t['color']) ?>"></span>
      <span><?= e($tn) ?></span>
      <span style="margin-left:auto;font-size:12.5px;opacity:.75"><?= e($t['label']) ?> · <?= number_format($t['rows']) ?> ແຖວ</span>
    </div>
    <div class="sql-body table-wrap">
      <table class="data">
        <thead>
          <tr><th>ຄໍລຳ</th><th>ປະເພດ</th><th>Null</th><th>ກຸນແຈ</th><th>ຄ່າເລີ່ມຕົ້ນ</th><th>ໝາຍເຫດ</th></tr>
        </thead>
        <tbody>
          <?php foreach ($t['cols'] as $c): ?>
            <?php
              $key = $c['Key'];
              $badge = '';
              if ($key === 'PRI') { $badge = '<span class="badge" style="color:#1d4ed8;background:#dbeafe">PK</span>'; }
              elseif ($key === 'UNI') { $badge = '<span class="badge" style="color:#475569;background:#e2e8f0">UNIQUE</span>'; }
              elseif ($key === 'MUL') { $badge = '<span class="badge" style="color:#b45309;background:#fef3c7">INDEX</span>'; }
              $fkTarget = $fkMap[$tn . '.' . $c['Field']] ?? null;
              if ($fkTarget) { $badge = '<span class="badge" style="color:#b45309;background:#ffedd5">FK → ' . e($fkTarget) . '</span>'; }
            ?>
            <tr>
              <td><code style="font-size:13.5px"><?= e($c['Field']) ?></code></td>
              <td class="muted" style="font-family:ui-monospace,Menlo,monospace;font-size:12.5px"><?= e($c['Type']) ?></td>
              <td class="muted small"><?= $c['Null'] === 'YES' ? '✓' : '—' ?></td>
              <td><?= $badge ?: '' ?></td>
              <td class="muted small" style="font-family:ui-monospace,Menlo,monospace"><?= e($c['Default'] ?? '—') ?></td>
              <td class="muted small"><?= e($c['Extra'] ?? '') ?><?= $c['Comment'] ? ' ' . e($c['Comment']) : '' ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div style="padding:12px 16px;border-top:1px solid var(--line);color:var(--muted);font-size:13.5px">
      <?= e($t['desc']) ?>
    </div>
  </section>
<?php endforeach; ?>

<div class="card card-pad" style="margin-top:8px">
  <h3 style="font-size:16px">ຄຳສັ່ງ SQL ທີ່ໃຊ້ເລື້ອຍໆ</h3>
  <pre style="background:#f8fafc;border:1px solid var(--line);border-radius:10px;padding:16px;overflow:auto;font-size:13px;line-height:1.7">
-- ຍອດຂາຍລາຍວັນ
SELECT DATE(order_date) AS d, COUNT(*) AS bills, SUM(total_amount) AS revenue
FROM orders WHERE status &lt;&gt; 'cancelled' GROUP BY DATE(order_date) ORDER BY d DESC;

-- ສິນຄ້າຂາຍດີ 5 ອັນດັບຕົ້ນ
SELECT p.product_name, SUM(oi.quantity) AS qty
FROM order_items oi JOIN products p ON p.product_id = oi.product_id
JOIN orders o ON o.order_id = oi.order_id AND o.status &lt;&gt; 'cancelled'
GROUP BY p.product_id ORDER BY qty DESC LIMIT 5;

-- ບິນທີ່ຍັງບໍ່ໄດ້ຈ່າຍ
SELECT o.order_id, o.total_amount FROM orders o
WHERE o.status &lt;&gt; 'cancelled' AND NOT EXISTS (
  SELECT 1 FROM payments p WHERE p.order_id = o.order_id AND p.payment_status = 'paid'
);</pre>
</div>

<?php admin_footer(); ?>
