/* ສິລປະ ບູຕິກ — ສະຄຣິບນ້ອຍໆ */
(function () {
  'use strict';

  // ເມນູຜູ້ໃຊ້
  document.querySelectorAll('.user-menu').forEach(function (menu) {
    var btn = menu.querySelector('.user-btn');
    if (!btn) return;
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      menu.classList.toggle('open');
    });
  });
  document.addEventListener('click', function () {
    document.querySelectorAll('.user-menu.open').forEach(function (m) {
      m.classList.remove('open');
    });
  });

  // ປຸ່ມ +/- ຈຳນວນ ໃນໜ້າກະຕ່າ
  document.querySelectorAll('.qty').forEach(function (box) {
    var input = box.querySelector('input');
    box.querySelectorAll('button').forEach(function (b) {
      b.addEventListener('click', function () {
        var step = b.dataset.step === 'up' ? 1 : -1;
        var max = parseInt(input.dataset.max || '999', 10);
        var v = (parseInt(input.value, 10) || 1) + step;
        v = Math.max(1, Math.min(max, v));
        input.value = v;
        // ສົ່ງຟອມອັດຕະໂນມັດ
        var form = input.closest('form');
        if (form && form.dataset.auto === '1') form.submit();
      });
    });
  });

  // ປິດ flash ອັດຕະໂນມັດ
  document.querySelectorAll('.flash').forEach(function (el) {
    setTimeout(function () {
      el.style.transition = 'opacity .4s';
      el.style.opacity = '0';
      setTimeout(function () { el.remove(); }, 420);
    }, 6000);
  });

  // ຢືນຢັນການລຶບ
  document.querySelectorAll('[data-confirm]').forEach(function (el) {
    el.addEventListener('submit', function (e) {
      if (!window.confirm(el.dataset.confirm)) e.preventDefault();
    });
  });
  document.querySelectorAll('a[data-confirm]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      if (!window.confirm(a.dataset.confirm)) e.preventDefault();
    });
  });
})();
