<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/ui.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $action = $_POST['action'] ?? '';
    $pid    = (int)($_POST['product_id'] ?? 0);
    $qty    = max(1, (int)($_POST['qty'] ?? 1));

    if ($action === 'add' && $pid > 0) {
        $p = q_one('SELECT * FROM products WHERE product_id = ? AND status <> ?', [$pid, 'inactive']);
        if (!$p) {
            flash('error', 'ບໍ່ພົບສິນຄ້ານີ້.');
        } elseif ((int)$p['stock_qty'] <= 0) {
            flash('error', 'ສິນຄ້າ “' . $p['product_name'] . '” ໝົດສະຕ໋ອກແລ້ວ.');
        } else {
            $cur = (int)($_SESSION['cart'][$pid] ?? 0);
            $new = min($cur + $qty, (int)$p['stock_qty']);
            $_SESSION['cart'][$pid] = $new;
            flash('success', 'ເພີ່ມ “' . $p['product_name'] . '” ໃສ່ກະຕ່າແລ້ວ (' . $new . ' ຊິ້ນ).');
        }
        redirect('cart.php');
    }

    if ($action === 'update' && $pid > 0) {
        $stock = (int)q_val('SELECT stock_qty FROM products WHERE product_id = ?', [$pid]);
        if ($qty <= 0) {
            unset($_SESSION['cart'][$pid]);
        } else {
            $_SESSION['cart'][$pid] = min($qty, max(1, $stock));
        }
        redirect('cart.php');
    }

    if ($action === 'remove' && $pid > 0) {
        unset($_SESSION['cart'][$pid]);
        flash('info', 'ລຶບລາຍການອອກຈາກກະຕ່າແລ້ວ.');
        redirect('cart.php');
    }

    if ($action === 'clear') {
        unset($_SESSION['cart']);
        flash('info', 'ລ້າງກະຕ່າແລ້ວ.');
        redirect('cart.php');
    }
}

$t = cart_totals();
$page_title = 'ກະຕ່າສິນຄ້າ';
require __DIR__ . '/includes/header.php';
?>

<div class="section-head" style="margin-top:0">
  <div>
    <span class="eyebrow">ຂັ້ນຕອນທີ 1 / 2</span>
    <h1>ກະຕ່າສິນຄ້າ</h1>
  </div>
  <?php if ($t['items']): ?>
    <form method="post" data-confirm="ຕ້ອງການລ້າງກະຕ່າທັງໝົດບໍ່?">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="clear">
      <button class="btn btn-ghost btn-sm" type="submit">ລ້າງກະຕ່າ</button>
    </form>
  <?php endif; ?>
</div>

<?php if (!$t['items']): ?>
  <div class="card card-pad empty-state">
    <div class="big">🛍️</div>
    <h2>ກະຕ່າຂອງທ່ານຫວ່າງເປົ່າ</h2>
    <p class="muted">ເລືອກເສື້ອຜ້າທີ່ທ່ານມັກ ແລ້ວເພີ່ມໃສ່ກະຕ່າໄດ້ເລີຍ.</p>
    <a class="btn btn-primary btn-lg" href="<?= e(url('index.php')) ?>">ເລືອກຊື້ສິນຄ້າ</a>
  </div>
<?php else: ?>
  <div class="cart-layout">
    <div class="card">
      <div class="card-head">
        <h2>ລາຍການ (<?= $t['count'] ?> ຊິ້ນ)</h2>
        <a class="btn btn-ghost btn-sm" href="<?= e(url('index.php')) ?>">+ ເພີ່ມສິນຄ້າ</a>
      </div>
      <div class="card-pad" style="padding-top:6px">
        <?php foreach ($t['items'] as $it): ?>
          <div class="cart-item">
            <?= product_thumb($it, 'cart-thumb') ?>
            <div>
              <a href="<?= e(url('product.php', ['id' => $it['product_id']])) ?>"><strong><?= e($it['product_name']) ?></strong></a>
              <div class="muted small"><?= e($it['category']) ?> · ຂະໜາດ <?= e($it['size'] ?: '-') ?> · ສີ <?= e($it['color'] ?: '-') ?></div>
              <div class="muted small"><?= money($it['price']) ?> / ຊິ້ນ · ຄົງເຫຼືອ <?= (int)$it['stock_qty'] ?></div>

              <div style="display:flex;gap:12px;align-items:center;margin-top:10px;flex-wrap:wrap">
                <form method="post" class="qty-form" data-auto="1" style="display:flex;gap:8px;align-items:center">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="update">
                  <input type="hidden" name="product_id" value="<?= (int)$it['product_id'] ?>">
                  <span class="qty">
                    <button type="button" data-step="down" aria-label="ຫຼຸດ">−</button>
                    <input type="number" name="qty" value="<?= (int)$it['qty'] ?>" min="1" max="<?= (int)$it['stock_qty'] ?>" data-max="<?= (int)$it['stock_qty'] ?>">
                    <button type="button" data-step="up" aria-label="ເພີ່ມ">+</button>
                  </span>
                  <button type="submit" class="btn btn-outline btn-sm">ອັບເດດ</button>
                </form>

                <form method="post" data-confirm="ລຶບລາຍການນີ້ອອກ?">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="remove">
                  <input type="hidden" name="product_id" value="<?= (int)$it['product_id'] ?>">
                  <button type="submit" class="btn btn-ghost btn-sm" style="color:#b91c1c">ລຶບ</button>
                </form>
              </div>
            </div>
            <div style="text-align:right">
              <strong style="font-size:17px"><?= money($it['line_total']) ?></strong>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <aside class="card card-pad summary">
      <h2 style="font-size:19px">ສະຫຼຸບຄ່າໃຊ້ຈ່າຍ</h2>
      <dl>
        <dt>ລວມຄ່າສິນຄ້າ</dt><dd><?= money($t['subtotal']) ?></dd>
        <dt>ຄ່າຂົນສົ່ງ</dt><dd><?= money($t['shipping']) ?></dd>
        <dt class="total-row">ຍອດລວມ</dt><dd class="total-row"><?= money($t['total']) ?></dd>
      </dl>
      <a class="btn btn-primary btn-block btn-lg" style="margin-top:20px" href="<?= e(url('checkout.php')) ?>">ດຳເນີນການສັ່ງຊື້</a>
      <p class="muted small" style="margin:12px 0 0;text-align:center">ຈ່າຍເງິນປາຍທາງ, ໂອນທະນາຄານ ຫຼື QR</p>
    </aside>
  </div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
