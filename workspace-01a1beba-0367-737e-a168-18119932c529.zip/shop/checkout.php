<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/ui.php';

require_customer();
$me = current_customer();
$t  = cart_totals();

if (!$t['items']) {
    flash('info', 'ກະຕ່າຂອງທ່ານຫວ່າງເປົ່າ — ເລືອກສິນຄ້າກ່ອນ.');
    redirect('index.php');
}

$errors = [];
$form = [
    'shipping_address' => $_POST['shipping_address'] ?? trim(($me['address'] ?? '') . (($me['city'] ?? '') ? ', ' . $me['city'] : '')),
    'payment_method'   => $_POST['payment_method'] ?? 'cod',
    'note'             => $_POST['note'] ?? '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $form['shipping_address'] = trim((string)$form['shipping_address']);
    $form['note']             = trim((string)$form['note']);
    $allowed = ['cod', 'bank_transfer', 'credit_card', 'qr_wallet'];

    if (mb_strlen($form['shipping_address']) < 10) {
        $errors[] = 'ກະລຸນາໃສ່ທີ່ຢູ່ຈັດສົ່ງໃຫ້ຄົບຖ້ວນ (ຢ່າງໜ້ອຍ 10 ຕົວອັກສອນ).';
    }
    if (!in_array($form['payment_method'], $allowed, true)) {
        $errors[] = 'ກະລຸນາເລືອກຊ່ອງທາງການຊຳລະ.';
    }

    // ກວດສະຕ໋ອກຄືນ (ກັນການສັ່ງຊື້ເກີນ)
    if (!$errors) {
        foreach ($t['items'] as $it) {
            if ($it['qty'] > (int)$it['stock_qty']) {
                $errors[] = 'ສິນຄ້າ “' . $it['product_name'] . '” ມີບໍ່ພຽງພໍ (ເຫຼືອ ' . $it['stock_qty'] . ' ຊິ້ນ).';
            }
        }
    }

    if (!$errors) {
        $pdo = db();
        try {
            $pdo->beginTransaction();

            $code = new_order_code();
            $note = $form['note'] !== '' ? $form['note'] : null;

            q_run(
                'INSERT INTO orders (customer_id, status, subtotal, shipping_fee, discount, total_amount, shipping_address, note)
                 VALUES (?, ?, ?, ?, 0, ?, ?, ?)',
                [$me['customer_id'], 'pending', $t['subtotal'], $t['shipping'], $t['total'], $form['shipping_address'], $note]
            );
            $orderId = (int)$pdo->lastInsertId();

            foreach ($t['items'] as $it) {
                q_run(
                    'INSERT INTO order_items (order_id, product_id, size, color, quantity, unit_price)
                     VALUES (?, ?, ?, ?, ?, ?)',
                    [$orderId, $it['product_id'], $it['size'], $it['color'], $it['qty'], $it['price']]
                );
                // ຕັດສະຕ໋ອກ
                q_run('UPDATE products SET stock_qty = stock_qty - ? WHERE product_id = ?', [$it['qty'], $it['product_id']]);
                q_run(
                    "UPDATE products SET status = 'out_of_stock'
                     WHERE product_id = ? AND stock_qty <= 0 AND status = 'active'",
                    [$it['product_id']]
                );
            }

            $payStatus = $form['payment_method'] === 'cod' ? 'pending' : 'pending';
            q_run(
                'INSERT INTO payments (order_id, payment_method, amount, payment_status, transaction_ref, paid_at)
                 VALUES (?, ?, ?, ?, NULL, NULL)',
                [$orderId, $form['payment_method'], $t['total'], $payStatus]
            );

            $pdo->commit();
            unset($_SESSION['cart']);
            $_SESSION['last_order'] = $orderId;   // ໃຊ້ສະແດງໜ້າສຳເລັດ
            flash('success', 'ສ້າງຄຳສັ່ງຊື້ເລກ #' . $code . ' ສຳເລັດແລ້ວ!');
            redirect('order_success.php', ['id' => $orderId]);
        } catch (Throwable $ex) {
            $pdo->rollBack();
            $errors[] = 'ເກີດຂໍ້ຜິດພາດ: ' . $ex->getMessage();
        }
    }
}

$page_title = 'ດຳເນີນການສັ່ງຊື້';
require __DIR__ . '/includes/header.php';
?>

<div class="steps">
  <span class="step on"><b>1</b> ກະຕ່າສິນຄ້າ</span>
  <span class="step on"><b>2</b> ທີ່ຢູ່ ແລະ ການຊຳລະ</span>
  <span class="step"><b>3</b> ສຳເລັດ</span>
</div>

<h1 style="margin-bottom:22px">ດຳເນີນການສັ່ງຊື້</h1>

<?php if ($errors): ?>
  <div class="flash flash-error" style="margin-bottom:18px">
    <?php foreach ($errors as $er): ?><div>• <?= e($er) ?></div><?php endforeach; ?>
  </div>
<?php endif; ?>

<form method="post" class="cart-layout">
  <?= csrf_field() ?>
  <div style="display:grid;gap:22px">
    <section class="card">
      <div class="card-head"><h2>1. ຂໍ້ມູນຈັດສົ່ງ</h2></div>
      <div class="card-pad form-grid">
        <div class="form-row">
          <div class="field">
            <label>ຜູ້ຮັບ</label>
            <input type="text" value="<?= e($me['full_name']) ?>" disabled>
            <span class="hint">ແກ້ໄຂໄດ້ໃນໜ້າໂປຣໄຟລ໌</span>
          </div>
          <div class="field">
            <label>ເບີໂທ</label>
            <input type="text" value="<?= e($me['phone']) ?>" disabled>
          </div>
        </div>
        <div class="field">
          <label for="shipping_address">ທີ່ຢູ່ຈັດສົ່ງ <span style="color:#b91c1c">*</span></label>
          <textarea id="shipping_address" name="shipping_address" required
                    placeholder="ບ້ານ / ບ້ານເລກທີ, ເມືອງ, ແຂວງ, ເບີໂທຕິດຕໍ່"><?= e($form['shipping_address']) ?></textarea>
        </div>
        <div class="field">
          <label for="note">ໝາຍເຫດເພີ່ມເຕີມ</label>
          <input type="text" id="note" name="note" value="<?= e($form['note']) ?>" placeholder="ເຊັ່ນ: ສົ່ງຕອນເຊົ້າ, ໂທກ່ອນສົ່ງ">
        </div>
      </div>
    </section>

    <section class="card">
      <div class="card-head"><h2>2. ຊ່ອງທາງການຊຳລະ</h2></div>
      <div class="card-pad form-grid">
        <?php
        $methods = [
            'cod'           => ['ເກັບເງິນປາຍທາງ (COD)', 'ຈ່າຍເງິນຕອນຮັບສິນຄ້າ'],
            'bank_transfer' => ['ໂອນທະນາຄານ', 'BCEL / LDB / ທະນາຄານອື່ນ'],
            'qr_wallet'     => ['QR / ກະເປົາເງິນ', 'OnePay, M-Money, ແອັບ QR'],
            'credit_card'   => ['ບັດເຄຣດິດ/ເດບິດ', 'Visa / Mastercard'],
        ];
        foreach ($methods as $k => $m): ?>
          <label class="checkbox" style="border:1px solid var(--line);border-radius:12px;padding:14px 16px;background:<?= $form['payment_method'] === $k ? 'var(--accent-soft)' : '#fff' ?>">
            <input type="radio" name="payment_method" value="<?= e($k) ?>" <?= $form['payment_method'] === $k ? 'checked' : '' ?>>
            <span>
              <strong><?= e($m[0]) ?></strong><br>
              <span class="muted small"><?= e($m[1]) ?></span>
            </span>
          </label>
        <?php endforeach; ?>
        <p class="muted small" style="margin:0">ໝາຍເຫດ: ການຊຳລະຈະຖືກຢືນຢັນໂດຍທີມງານຮ້ານຫຼັງຈາກສັ່ງຊື້.</p>
      </div>
    </section>
  </div>

  <aside class="card card-pad summary">
    <h2 style="font-size:19px">ສະຫຼຸບຄຳສັ່ງຊື້</h2>
    <div style="display:grid;gap:10px;margin-bottom:16px">
      <?php foreach ($t['items'] as $it): ?>
        <div style="display:flex;justify-content:space-between;gap:12px;font-size:14.5px">
          <span><?= e($it['product_name']) ?> <span class="muted">×<?= (int)$it['qty'] ?></span></span>
          <strong><?= money($it['line_total']) ?></strong>
        </div>
      <?php endforeach; ?>
    </div>
    <dl>
      <dt>ລວມຄ່າສິນຄ້າ</dt><dd><?= money($t['subtotal']) ?></dd>
      <dt>ຄ່າຂົນສົ່ງ</dt><dd><?= money($t['shipping']) ?></dd>
      <dt class="total-row">ຍອດລວມ</dt><dd class="total-row"><?= money($t['total']) ?></dd>
    </dl>
    <button class="btn btn-primary btn-block btn-lg" type="submit" style="margin-top:20px">✓ ຢືນຢັນການສັ່ງຊື້</button>
    <a class="btn btn-ghost btn-block" href="<?= e(url('cart.php')) ?>" style="margin-top:8px">← ກັບໄປກະຕ່າ</a>
  </aside>
</form>

<?php require __DIR__ . '/includes/footer.php'; ?>
