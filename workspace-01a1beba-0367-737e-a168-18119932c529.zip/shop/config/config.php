<?php
/**
 * ຕັ້ງຄ່າລະບົບ — ຮ້ານຂາຍເສື້ອຜ້າອອນລາຍ
 * ແກ້ໄຂຄ່ານີ້ໃຫ້ກົງກັບເຊີບເວີຂອງທ່ານ
 */
declare(strict_types=1);

// ---- MySQL ----
const DB_HOST = '127.0.0.1';
const DB_PORT = 3306;
const DB_NAME = 'shop_db';
const DB_USER = 'shop';
const DB_PASS = 'shop1234';

// ---- ຜູ້ດູແລລະບົບ (admin) ----
// ເກັບໄວ້ໃນ config ເພື່ອຮັກສາຈຳນວນຕາຕະລາງໃຫ້ບໍ່ເກີນ 5 ຕາມກຳນົດ
const ADMIN_USER = 'admin';
const ADMIN_PASS = 'admin123';

// ---- ຂໍ້ມູນຮ້ານ ----
const SHOP_NAME  = 'ສິລປະ ບູຕິກ';
const SHOP_LATIN = 'Silpa Boutique';
const SHOP_PHONE = '020 5551 1111';
const SHOP_EMAIL = 'hello@silpaboutique.la';

// ---- ຄ່າເງິນ ----
const CURRENCY = '₭';
const SHIPPING_FEE_DEFAULT = 20000;

// ---- ການຕັ້ງຄ່າ session ----
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

date_default_timezone_set('Asia/Vientiane');

// ---- ຄິດໄລ່ BASE_URL ອັດຕະໂນມັດ (ໃຊ້ໄດ້ທັງໜ້າຫຼັກ ແລະ ໜ້າ admin/) ----
if (!defined('BASE_URL')) {
    $appRoot = str_replace('\\', '/', dirname(__DIR__));           // .../shop
    $docRoot = str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '');
    $base = ($docRoot && str_starts_with($appRoot, $docRoot))
        ? substr($appRoot, strlen($docRoot))
        : str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
    define('BASE_URL', rtrim($base, '/'));
}
