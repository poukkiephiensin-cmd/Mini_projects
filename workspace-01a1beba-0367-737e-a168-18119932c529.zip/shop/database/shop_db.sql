-- ============================================================
--  ຖານຂໍ້ມູນ: shop_db — ລະບົບຮ້ານຂາຍເສື້ອຜ້າອອນລາຍ
--  MySQL 8 / MariaDB 10+  ·  utf8mb4 (ຮອງຮັບພາສາລາວ)
--  ມີ 5 ຕາຕະລາງ: customers, products, orders, order_items, payments
-- ============================================================
-- ບັງຄັບ charset ຂອງການເຊື່ອມຕໍ່ (ສຳຄັນຫຼາຍສຳລັບພາສາລາວ)
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

DROP DATABASE IF EXISTS shop_db;
CREATE DATABASE shop_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE shop_db;

-- ------------------------------------------------------------
-- 1) customers — ລູກຄ້າ
-- ------------------------------------------------------------
CREATE TABLE customers (
  customer_id   INT           NOT NULL AUTO_INCREMENT,
  full_name     VARCHAR(100)  NOT NULL,
  gender        ENUM('M','F','O') NULL,
  phone         VARCHAR(20)   NOT NULL,
  email         VARCHAR(100)  NULL,
  password_hash VARCHAR(255)  NOT NULL,
  address       VARCHAR(255)  NULL,
  city          VARCHAR(100)  NULL,
  created_at    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (customer_id),
  UNIQUE KEY uq_customers_phone (phone),
  UNIQUE KEY uq_customers_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 2) products — ສິນຄ້າ (1 ແຖວ = 1 SKU: ສິນຄ້າ + ຂະໜາດ + ສີ)
-- ------------------------------------------------------------
CREATE TABLE products (
  product_id   INT            NOT NULL AUTO_INCREMENT,
  product_name VARCHAR(150)   NOT NULL,
  category     VARCHAR(50)    NOT NULL,
  brand        VARCHAR(80)    NULL,
  size         VARCHAR(20)    NULL,
  color        VARCHAR(40)    NULL,
  description  TEXT           NULL,
  price        DECIMAL(12,2)  NOT NULL,
  cost_price   DECIMAL(12,2)  NULL,
  stock_qty    INT            NOT NULL DEFAULT 0,
  image_url    VARCHAR(255)   NULL,
  status       ENUM('active','inactive','out_of_stock') NOT NULL DEFAULT 'active',
  created_at   DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (product_id),
  KEY idx_products_category (category),
  CONSTRAINT chk_products_price CHECK (price >= 0),
  CONSTRAINT chk_products_cost  CHECK (cost_price IS NULL OR cost_price >= 0),
  CONSTRAINT chk_products_stock CHECK (stock_qty >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 3) orders — ຄຳສັ່ງຊື້
-- ------------------------------------------------------------
CREATE TABLE orders (
  order_id         INT           NOT NULL AUTO_INCREMENT,
  customer_id      INT           NOT NULL,
  order_date       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status           ENUM('pending','confirmed','packing','shipped','delivered','cancelled')
                                 NOT NULL DEFAULT 'pending',
  subtotal         DECIMAL(12,2) NOT NULL DEFAULT 0,
  shipping_fee     DECIMAL(12,2) NOT NULL DEFAULT 0,
  discount         DECIMAL(12,2) NOT NULL DEFAULT 0,
  total_amount     DECIMAL(12,2) NOT NULL,
  shipping_address VARCHAR(255)  NOT NULL,
  note             VARCHAR(255)  NULL,
  created_at       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (order_id),
  KEY idx_orders_customer (customer_id),
  KEY idx_orders_date (order_date),
  CONSTRAINT fk_orders_customer FOREIGN KEY (customer_id)
    REFERENCES customers (customer_id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT chk_orders_subtotal CHECK (subtotal >= 0),
  CONSTRAINT chk_orders_total    CHECK (total_amount >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 4) order_items — ລາຍລະອຽດຄຳສັ່ງຊື້
-- ------------------------------------------------------------
CREATE TABLE order_items (
  item_id    INT           NOT NULL AUTO_INCREMENT,
  order_id   INT           NOT NULL,
  product_id INT           NOT NULL,
  size       VARCHAR(20)   NULL,
  color      VARCHAR(40)   NULL,
  quantity   INT           NOT NULL,
  unit_price DECIMAL(12,2) NOT NULL,
  line_total DECIMAL(12,2) GENERATED ALWAYS AS (quantity * unit_price) STORED,
  PRIMARY KEY (item_id),
  KEY idx_items_order   (order_id),
  KEY idx_items_product (product_id),
  CONSTRAINT fk_items_order FOREIGN KEY (order_id)
    REFERENCES orders (order_id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_items_product FOREIGN KEY (product_id)
    REFERENCES products (product_id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT chk_items_qty   CHECK (quantity > 0),
  CONSTRAINT chk_items_price CHECK (unit_price >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 5) payments — ການຊຳລະເງິນ
-- ------------------------------------------------------------
CREATE TABLE payments (
  payment_id      INT           NOT NULL AUTO_INCREMENT,
  order_id        INT           NOT NULL,
  payment_method  ENUM('cod','bank_transfer','credit_card','qr_wallet') NOT NULL,
  amount          DECIMAL(12,2) NOT NULL,
  payment_status  ENUM('pending','paid','failed','refunded') NOT NULL DEFAULT 'pending',
  transaction_ref VARCHAR(100)  NULL,
  paid_at         DATETIME      NULL,
  created_at      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (payment_id),
  KEY idx_payments_order  (order_id),
  KEY idx_payments_status (payment_status),
  CONSTRAINT fk_payments_order FOREIGN KEY (order_id)
    REFERENCES orders (order_id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_payments_amount CHECK (amount > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
--  ຂໍ້ມູນຕົວຢ່າງ
--  ລະຫັດຜ່ານຕົວຢ່າງ: 123456  (bcrypt hash ຂ້າງລຸ່ມ)
-- ============================================================
SET @pw = '$2y$12$8lvE0NGh6anHZcjyB9llhu9hGD1liahaGmf4BuUQcvGa4X1tNBLei';

INSERT INTO customers (full_name, gender, phone, email, password_hash, address, city) VALUES
('ສົມພອນ ວົງສະຫວັນ', 'F', '02055511111', 'somphone@example.com', @pw, 'ບ້ານ ທົ່ງຄັນຄາມ, ຈັນທະບູລີ', 'ວຽງຈັນ'),
('ຄຳພອນ ສີສຸວັນ',   'M', '02055522222', 'khamphon@example.com', @pw, 'ບ້ານ ສີສັດຕະນາກ, ຈັນທະບູລີ', 'ວຽງຈັນ'),
('ນາລີ ພົມມະຈັນ',   'F', '02055533333', 'nalee@example.com',    @pw, 'ບ້ານ ດອນກອຍ, ສີສັດຕະນາກ', 'ວຽງຈັນ'),
('ບຸນມີ ແກ້ວມະນີ',   'M', '02055544444', NULL,                   @pw, 'ບ້ານ ຜາກູ້, ຫຼວງພະບາງ', 'ຫຼວງພະບາງ');

INSERT INTO products (product_name, category, brand, size, color, description, price, cost_price, stock_qty, status) VALUES
('ເສື້ອຢືດຄໍກົມ ຝ້າຍ 100%', 'ເສື້ອ', 'LaoStyle', 'M',  'ດຳ',      'ເສື້ອຢືດຄໍກົມ ຜ້າຝ້າຍໜານຸ່ມ ໃສ່ງ່າຍ', 120000, 70000, 42, 'active'),
('ເສື້ອຢືດຄໍກົມ ຝ້າຍ 100%', 'ເສື້ອ', 'LaoStyle', 'L',  'ດຳ',      'ເສື້ອຢືດຄໍກົມ ຜ້າຝ້າຍໜານຸ່ມ ໃສ່ງ່າຍ', 120000, 70000, 28, 'active'),
('ເສື້ອຢືດຄໍກົມ ຝ້າຍ 100%', 'ເສື້ອ', 'LaoStyle', 'XL', 'ຂາວ',     'ເສື້ອຢືດຄໍກົມ ຜ້າຝ້າຍໜານຸ່ມ ໃສ່ງ່າຍ', 135000, 80000, 16, 'active'),
('ເສື້ອເຊີດຍາວ ແຂນສັ້ນ',    'ເສື້ອ', 'Bloom',    'S',  'ຂາວ',     'ເສື້ອເຊີດຜ້າລິນນິນ ໃສ່ໄດ້ທຸກວັນ',       180000, 110000, 30, 'active'),
('ເສື້ອເຊີດຍາວ ແຂນສັ້ນ',    'ເສື້ອ', 'Bloom',    'M',  'ຟ້າ',     'ເສື້ອເຊີດຜ້າລິນນິນ ໃສ່ໄດ້ທຸກວັນ',       180000, 110000, 24, 'active'),
('ສິ້ນຊີ້ງໄໝລາວ ລາຍພື້ນເມືອງ', 'ສິ້ນ',  'SilkLao',  'M',  'ແດງ',     'ສິ້ນໄໝທໍມື ລາຍພື້ນເມືອງລາວ',            350000, 220000, 15, 'active'),
('ສິ້ນຊີ້ງໄໝລາວ ລາຍພື້ນເມືອງ', 'ສິ້ນ',  'SilkLao',  'L',  'ມ່ວງ',    'ສິ້ນໄໝທໍມື ລາຍພື້ນເມືອງລາວ',            380000, 240000, 9,  'active'),
('ໂສ້ງຂາຍາວຢີນ ສີຄີມ',      'ໂສ້ງ',  'DenimCo',  '32', 'ຄີມ',     'ໂສ້ງຢີນຜ້າໜາ ຕັດຊົງກົງ',                250000, 160000, 20, 'active'),
('ໂສ້ງຂາຍາວຢີນ ສີຄີມ',      'ໂສ້ງ',  'DenimCo',  '34', 'ຄີມ',     'ໂສ້ງຢີນຜ້າໜາ ຕັດຊົງກົງ',                250000, 160000, 12, 'active'),
('ໂສ້ງສັ້ນຜ້າລີນນິນ',       'ໂສ້ງ',  'LaoStyle', 'M',  'ເທົາ',    'ໂສ້ງສັ້ນຜ້າລີນນິນ ໃສ່ສະບາຍ',             165000, 95000,  26, 'active'),
('ເສື້ອກັນໜາວ ຜ້າຂົນແກະ',    'ເສື້ອ', 'WarmLao',  'L',  'ນ້ຳຕານ',  'ເສື້ອກັນໜາວ ຜ້າຂົນແກະ ສຳລັບລະດູໜາວ',     420000, 280000, 8,  'active'),
('ໝວກບີນນີ ປັບຂະໜາດໄດ້',   'ໝວກ',  'CapLao',   'Free','ດຳ',     'ໝວກບີນນີ ປັບສາຍຮັດໄດ້',               45000,  25000,  60, 'active'),
('ກະເປົ໋າຜ້າແພ ລາຍລາວ',      'ກະເປົ໋າ', 'SilkLao', 'Free','ລາຍ',   'ກະເປົ໋າຜ້າແພ ລາຍພື້ນເມືອງ',              155000, 90000,  18, 'active'),
('ເຂັມຂັດຜ້າໄໝ',           'ເຄື່ອງປະດັບ','SilkLao','Free','ທອງ',  'ເຂັມຂັດຫັດຖະກຳ ຈາກຜ້າໄໝ',                85000,  48000,  22, 'active'),
('ເສື້ອພື້ນເມືອງ ລາຍດອກ',     'ເສື້ອ', 'LaoStyle', 'M',  'ບົວ',     'ເສື້ອພື້ນເມືອງ ຜ້າຝ້າຍ ລາຍດອກ',           290000, 180000, 0,  'out_of_stock'),
('ເກີບແຕະ ຜົງແພ',           'ເກີບ',  'LaoStep',  '38', 'ເທົາ',    'ເກີບແຕະຜົງແພ ສຳລັບໃສ່ທຸກວັນ',            195000, 120000, 14, 'active');

INSERT INTO orders (customer_id, order_date, status, subtotal, shipping_fee, discount, total_amount, shipping_address, note, created_at) VALUES
(1, '2026-10-26 09:12:00', 'delivered', 510000, 20000, 0,      530000, 'ບ້ານ ທົ່ງຄັນຄາມ, ຈັນທະບູລີ, ວຽງຈັນ', 'ສົ່ງຕອນເຊົ້າ', '2026-10-26 09:12:00'),
(2, '2026-10-29 14:40:00', 'delivered', 730000, 20000, 30000,  720000, 'ບ້ານ ສີສັດຕະນາກ, ຈັນທະບູລີ, ວຽງຈັນ', NULL, '2026-10-29 14:40:00'),
(3, '2026-11-02 10:05:00', 'shipped',   545000, 20000, 0,      565000, 'ບ້ານ ດອນກອຍ, ສີສັດຕະນາກ, ວຽງຈັນ', 'ໂທກ່ອນສົ່ງ', '2026-11-02 10:05:00'),
(4, '2026-11-05 16:22:00', 'packing',   420000, 25000, 0,      445000, 'ບ້ານ ຜາກູ້, ເມືອງ, ຫຼວງພະບາງ', NULL, '2026-11-05 16:22:00'),
(1, '2026-11-07 08:48:00', 'pending',   275000, 20000, 0,      295000, 'ບ້ານ ທົ່ງຄັນຄາມ, ຈັນທະບູລີ, ວຽງຈັນ', NULL, '2026-11-07 08:48:00'),
(2, '2026-11-08 19:30:00', 'confirmed', 380000, 20000, 0,      400000, 'ບ້ານ ສີສັດຕະນາກ, ຈັນທະບູລີ, ວຽງຈັນ', NULL, '2026-11-08 19:30:00');

INSERT INTO order_items (order_id, product_id, size, color, quantity, unit_price) VALUES
(1, 1, 'M', 'ດຳ',   2, 120000),
(1, 13,'Free','ດຳ', 3, 45000),
(1, 14,'Free','ລາຍ',1, 155000),
(2, 6, 'M', 'ແດງ',  1, 350000),
(2, 7, 'L', 'ມ່ວງ', 1, 380000),
(3, 9, '32','ຄີມ',  1, 250000),
(3, 4, 'S', 'ຂາວ',  1, 180000),
(3, 15,'Free','ທອງ',1, 85000),
(4, 11,'M', 'ເທົາ', 1, 165000),
(4, 10,'M', 'ເທົານ້ຳຕານ', 1, 255000),
(5, 3, 'XL','ຂາວ',  1, 135000),
(5, 13,'Free','ດຳ', 1, 45000),
(5, 14,'Free','ລາຍ',1, 95000),
(6, 12,'L', 'ນ້ຳຕານ',1, 380000);

INSERT INTO payments (order_id, payment_method, amount, payment_status, transaction_ref, paid_at, created_at) VALUES
(1, 'cod',           530000, 'paid',    NULL,              '2026-10-28 11:30:00', '2026-10-26 09:12:00'),
(2, 'bank_transfer', 720000, 'paid',    'BCEL-8842103',    '2026-10-29 15:02:00', '2026-10-29 14:40:00'),
(3, 'qr_wallet',     565000, 'paid',    'ONELAB-9920114',  '2026-11-02 10:20:00', '2026-11-02 10:05:00'),
(4, 'cod',           445000, 'pending', NULL,              NULL,                  '2026-11-05 16:22:00'),
(5, 'qr_wallet',     295000, 'pending', NULL,              NULL,                  '2026-11-07 08:48:00'),
(6, 'credit_card',   400000, 'paid',    'CARD-5567-0219',  '2026-11-08 19:33:00', '2026-11-08 19:30:00');

-- ============================================================
--  ໝາຍເຫດ: ລະຫັດຜ່ານຕົວຢ່າງຂ້າງເທິງເປັນ hash ຂອງ "123456"
--  ຖ້າຕ້ອງການ hash ໃໝ່ ໃຫ້ແລ່ນ: php -r "echo password_hash('123456', PASSWORD_DEFAULT);"
-- ============================================================
