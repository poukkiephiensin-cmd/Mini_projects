<?php
/** ເລົ້າທີ່ຢູ່ຂອງໜ້າຜູ້ດູແລລະບົບ */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/ui.php';

function admin_header(string $title, string $active = ''): void
{
    $flashes = take_flashes();
    $menu = [
        'dashboard' => ['index.php', '📊', 'ແດຊບອດ'],
        'orders'    => ['orders.php', '🧾', 'ຄຳສັ່ງຊື້'],
        'products'  => ['products.php', '👕', 'ສິນຄ້າ'],
        'customers' => ['customers.php', '👥', 'ລູກຄ້າ'],
        'schema'    => ['schema.php', '🗄️', 'ໂຄງສ້າງຖານຂໍ້ມູນ'],
    ];
    ?>
<!doctype html>
<html lang="lo">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> — ຜູ້ດູແລລະບົບ</title>
<link rel="stylesheet" href="<?= e(BASE_URL) ?>/assets/css/style.css">
</head>
<body class="admin-body">
<div class="admin-shell">
  <aside class="sidebar">
    <a class="brand" href="<?= e(BASE_URL) ?>/admin/index.php">
      <span class="brand-mark">ສ</span>
      <span class="brand-text">
        <strong><?= e(SHOP_NAME) ?></strong>
        <small>ຜູ້ດູແລລະບົບ</small>
      </span>
    </a>
    <nav class="side-nav">
      <?php foreach ($menu as $key => [$href, $ico, $label]): ?>
        <a class="<?= $active === $key ? 'active' : '' ?>" href="<?= e(BASE_URL . '/admin/' . $href) ?>">
          <span class="ico"><?= $ico ?></span> <?= e($label) ?>
        </a>
      <?php endforeach; ?>
    </nav>
    <div class="side-foot">
      <div style="margin-bottom:10px">ເຂົ້າໃຊ້: <strong style="color:#fff"><?= e($_SESSION['admin_user'] ?? 'admin') ?></strong></div>
      <a href="<?= e(BASE_URL) ?>/index.php" style="color:#c3c9d3">↗ ໄປໜ້າຮ້ານ</a><br>
      <a href="<?= e(BASE_URL) ?>/admin/logout.php" style="color:#f0a06a">ອອກຈາກລະບົບ</a>
    </div>
  </aside>

  <main class="admin-main">
    <?php if ($flashes): ?>
      <div class="flash-stack" style="margin:0 0 18px">
        <?php foreach ($flashes as $f): ?>
          <div class="flash flash-<?= e($f['type']) ?>"><?= e($f['msg']) ?></div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
    <?php
}

function admin_footer(): void
{
    ?>
  </main>
</div>
<script src="<?= e(BASE_URL) ?>/assets/js/app.js"></script>
</body>
</html>
    <?php
}

/** ແຖບກຣາຟແບບ SVG (ບໍ່ຕ້ອງໃຊ້ CDN) */
function bar_chart(array $labels, array $values, int $w = 640, int $h = 220): string
{
    $max = max(1, ...array_map('floatval', $values));
    $n = max(1, count($values));
    $padL = 46; $padB = 30; $padT = 14; $padR = 10;
    $cw = ($w - $padL - $padR) / $n;
    $bars = '';
    foreach (array_values($values) as $i => $v) {
        $bh = ($h - $padT - $padB) * ($max > 0 ? (float)$v / $max : 0);
        $x = $padL + $i * $cw + $cw * 0.18;
        $bw = $cw * 0.64;
        $y = $h - $padB - $bh;
        $bars .= sprintf(
            '<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="5" fill="#b83d0a" opacity="%.2f"></rect>',
            $x, $y, $bw, max(2, $bh), 0.55 + 0.4 * ((float)$v / $max)
        );
        $bars .= sprintf(
            '<text x="%.1f" y="%.1f" text-anchor="middle" font-size="11" fill="#717784">%s</text>',
            $x + $bw / 2, $h - $padB + 18, htmlspecialchars((string)$labels[$i], ENT_QUOTES, 'UTF-8')
        );
    }
    // ເສັ້ນພື້ນ
    $grid = '';
    for ($g = 0; $g <= 3; $g++) {
        $yy = $h - $padB - ($h - $padT - $padB) * $g / 3;
        $grid .= sprintf('<line x1="%d" y1="%.1f" x2="%d" y2="%.1f" stroke="#e6e2da" stroke-width="1"></line>', $padL, $yy, $w - $padR, $yy);
        $grid .= sprintf(
            '<text x="%d" y="%.1f" text-anchor="end" font-size="10.5" fill="#9aa0a8">%s</text>',
            $padL - 8, $yy + 4, htmlspecialchars(number_format($max * $g / 3 / 1000, 0) . 'k', ENT_QUOTES, 'UTF-8')
        );
    }
    return '<svg viewBox="0 0 ' . $w . ' ' . $h . '" width="100%" height="' . $h . '" role="img" aria-label="ກຣາຟຍອດຂາຍ">'
        . $grid . $bars . '</svg>';
}

/** ວົງມົນສັດສ່ວນ */
function donut_chart(array $data): string
{
    $total = array_sum($data);
    $colors = ['#b83d0a', '#0f6b5f', '#b98b24', '#7c3aed', '#0891b2', '#db2777', '#64748b'];
    $r = 54; $cx = 70; $cy = 70; $stroke = 22; $circ = 2 * M_PI * $r;
    $off = 0.0;
    $seg = '';
    $i = 0;
    foreach ($data as $k => $v) {
        if ($total <= 0) break;
        $len = $circ * ((float)$v / $total);
        $seg .= sprintf(
            '<circle cx="%d" cy="%d" r="%d" fill="none" stroke="%s" stroke-width="%d"
             stroke-dasharray="%.2f %.2f" stroke-dashoffset="%.2f" transform="rotate(-90 %d %d)"></circle>',
            $cx, $cy, $r, $colors[$i % count($colors)], $stroke, max(0.5, $len - 3), $circ, -$off, $cx, $cy
        );
        $off += $len;
        $i++;
    }
    if ($total <= 0) {
        $seg = '<circle cx="70" cy="70" r="54" fill="none" stroke="#e6e2da" stroke-width="22"></circle>';
    }
    return '<svg viewBox="0 0 140 140" width="140" height="140" role="img" aria-label="ສັດສ່ວນໝວດ">' . $seg . '</svg>';
}
