<?php
/**
 * ເຊື່ອມຕໍ່ຖານຂໍ້ມູນ + ຟັງຊັນຊ່ວຍເຫຼືອທົ່ວລະບົບ
 */
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';

/** @return PDO */
function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', DB_HOST, DB_PORT, DB_NAME);
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo '<!doctype html><meta charset="utf-8"><title>ຖານຂໍ້ມູນ</title>'
            . '<div style="font-family:sans-serif;max-width:640px;margin:80px auto;padding:24px;'
            . 'border:1px solid #e2e8f0;border-radius:12px;background:#fff;color:#0f172a">'
            . '<h2 style="margin:0 0 8px">ເຊື່ອມຕໍ່ຖານຂໍ້ມູນບໍ່ໄດ້</h2>'
            . '<p style="color:#64748b">ກະລຸນາກວດສອບວ່າ MySQL ກຳລັງແລ່ນ ແລະ ນຳເຂົ້າໄຟລ໌ '
            . '<code>database/shop_db.sql</code> ແລ້ວ.</p>'
            . '<pre style="background:#f8fafc;padding:12px;border-radius:8px;overflow:auto">'
            . htmlspecialchars($e->getMessage()) . '</pre></div>';
        exit;
    }
    return $pdo;
}

/** ດຶງຫຼາຍແຖວ */
function q_all(string $sql, array $params = []): array
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

/** ດຶງແຖວດຽວ (ຫຼື null) */
function q_one(string $sql, array $params = []): ?array
{
    $st = db()->prepare($sql);
    $st->execute($params);
    $row = $st->fetch();
    return $row === false ? null : $row;
}

/** ດຶງຄ່າດຽວ */
function q_val(string $sql, array $params = [])
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchColumn();
}

/** ປະຕິບັດຄຳສັ່ງ INSERT/UPDATE/DELETE */
function q_run(string $sql, array $params = []): int
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->rowCount();
}

// ---------------- ຕົວຊ່ວຍເຫຼືອ ----------------

/** ແປງເປັນ HTML ທີ່ປອດໄພ */
function e($v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** ຮູບແບບເງິນ */
function money($amount): string
{
    return number_format((float)$amount, 0, '.', ',') . ' ' . CURRENCY;
}

/** ປ້ອງກັນ XSS ໃນ URL */
function url(string $path = '', array $params = []): string
{
    $u = BASE_URL . '/' . ltrim($path, '/');
    if ($params) {
        $u .= '?' . http_build_query($params);
    }
    return $u;
}

/** ປ່ຽນໜ້າ */
function redirect(string $path, array $params = []): void
{
    header('Location: ' . url($path, $params));
    exit;
}

/** flash message */
function flash(string $type, string $msg): void
{
    $_SESSION['flash'][] = ['type' => $type, 'msg' => $msg];
}

function take_flashes(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

/** CSRF token */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function check_csrf(): void
{
    $expected = $_SESSION['csrf'] ?? '';
    $given    = $_POST['csrf'] ?? '';
    // ຕ້ອງມີ token ທັງສອງຝ່າຍ ແລະ ຕ້ອງກົງກັນ (ປ້ອງກັນກໍລະນີ session token ຫວ່າງ)
    if ($expected === '' || !is_string($given) || !hash_equals($expected, $given)) {
        http_response_code(419);
        exit('CSRF token ບໍ່ຖືກຕ້ອງ ຫຼື ໝົດອາຍຸ — ກະລຸນາໂຫຼດໜ້າໃໝ່ແລ້ວລອງອີກຄັ້ງ.');
    }
}

// ---------------- ຜູ້ໃຊ້ / ສິດ ----------------

function current_customer(): ?array
{
    if (empty($_SESSION['customer_id'])) {
        return null;
    }
    static $c = null;
    if ($c === null) {
        $c = q_one('SELECT * FROM customers WHERE customer_id = ?', [$_SESSION['customer_id']]);
    }
    return $c ?: null;
}

function is_customer(): bool
{
    return current_customer() !== null;
}

function is_admin(): bool
{
    return !empty($_SESSION['is_admin']);
}

function require_customer(): void
{
    if (!is_customer()) {
        flash('warning', 'ກະລຸນາເຂົ້າສູ່ລະບົບ ກ່ອນສັ່ງຊື້.');
        redirect('login.php', ['next' => $_SERVER['REQUEST_URI'] ?? 'index.php']);
    }
}

function require_admin(): void
{
    if (!is_admin()) {
        flash('warning', 'ກະລຸນາເຂົ້າສູ່ລະບົບເປັນຜູ້ດູແລລະບົບ.');
        redirect('admin/login.php');
    }
}

/** ຕະກອນ */
function cart(): array
{
    return $_SESSION['cart'] ?? [];
}

function cart_count(): int
{
    return array_sum(cart());
}

/** ຂໍ້ຄວາມສະຖານະ */
function status_label(string $s): array
{
    $map = [
        'pending'    => ['ລໍຖ້າຢືນຢັນ', '#b45309', '#fef3c7'],
        'confirmed'  => ['ຢືນຢັນແລ້ວ', '#1d4ed8', '#dbeafe'],
        'packing'    => ['ກຳລັງຫຸ້ມຫໍ່', '#7c3aed', '#ede9fe'],
        'shipped'    => ['ກຳລັງສົ່ງ', '#0891b2', '#cffafe'],
        'delivered'  => ['ສົ່ງສຳເລັດ', '#047857', '#d1fae5'],
        'cancelled'  => ['ຍົກເລີກ', '#b91c1c', '#fee2e2'],
        'paid'       => ['ຈ່າຍແລ້ວ', '#047857', '#d1fae5'],
        'failed'     => ['ຈ່າຍບໍ່ສຳເລັດ', '#b91c1c', '#fee2e2'],
        'refunded'   => ['ຄືນເງິນ', '#7c3aed', '#ede9fe'],
        'active'     => ['ຂາຍຢູ່', '#047857', '#d1fae5'],
        'inactive'   => ['ປິດຂາຍ', '#64748b', '#e2e8f0'],
        'out_of_stock' => ['ໝົດສະຕ໋ອກ', '#b91c1c', '#fee2e2'],
    ];
    return $map[$s] ?? [$s, '#334155', '#e2e8f0'];
}

function status_badge(string $s): string
{
    [$label, $fg, $bg] = status_label($s);
    return '<span class="badge" style="color:' . $fg . ';background:' . $bg . '">' . e($label) . '</span>';
}

function payment_label(string $m): string
{
    return [
        'cod'           => 'ເກັບເງິນປາຍທາງ (COD)',
        'bank_transfer' => 'ໂອນທະນາຄານ',
        'credit_card'   => 'ບັດເຄຣດິດ',
        'qr_wallet'     => 'QR / ກະເປົາເງິນ',
    ][$m] ?? $m;
}

/** ສ້າງເລກບິນ */
function new_order_code(): string
{
    return 'ORD-' . date('ymd') . '-' . strtoupper(bin2hex(random_bytes(2)));
}

/** ຄຳນວນຍອດໃນຕະກອນ ຈາກຖານຂໍ້ມູນ */
function cart_totals(): array
{
    $c = cart();
    $subtotal = 0.0;
    $items = [];
    if ($c) {
        $ids = array_keys($c);
        $ph = implode(',', array_fill(0, count($ids), '?'));
        $rows = q_all("SELECT * FROM products WHERE product_id IN ($ph)", $ids);
        foreach ($rows as $p) {
            $qty = (int)$c[$p['product_id']];
            $p['qty'] = $qty;
            $p['line_total'] = $qty * (float)$p['price'];
            $subtotal += $p['line_total'];
            $items[] = $p;
        }
    }
    $shipping = $items ? SHIPPING_FEE_DEFAULT : 0;
    return [
        'items'    => $items,
        'subtotal' => $subtotal,
        'shipping' => $shipping,
        'total'    => $subtotal + $shipping,
        'count'    => cart_count(),
    ];
}
