</main>

<footer class="site-footer">
  <div class="wrap footer-in">
    <div>
      <strong><?= e(SHOP_NAME) ?></strong>
      <p class="muted">ເສື້ອຜ້າລາວຄຸນນະພາບ · ສັ່ງຊື້ອອນລາຍ ສົ່ງທົ່ວປະເທດ</p>
    </div>
    <div class="footer-cols">
      <div>
        <h4>ຕິດຕໍ່</h4>
        <p class="muted">☎ <?= e(SHOP_PHONE) ?><br>✉ <?= e(SHOP_EMAIL) ?></p>
      </div>
      <div>
        <h4>ລິ້ງ</h4>
        <p class="muted">
          <a href="<?= e(BASE_URL) ?>/index.php">ໜ້າຫຼັກ</a><br>
          <a href="<?= e(BASE_URL) ?>/orders.php">ຕິດຕາມຄຳສັ່ງຊື້</a><br>
          <a href="<?= e(BASE_URL) ?>/admin/login.php">ຜູ້ດູແລລະບົບ</a>
        </p>
      </div>
    </div>
  </div>
  <div class="wrap footer-bottom">© <?= date('Y') ?> <?= e(SHOP_NAME) ?> — ລະບົບຮ້ານຂາຍເສື້ອຜ້າອອນລາຍ (MySQL · PHP)</div>
</footer>

<script src="<?= e(BASE_URL) ?>/assets/js/app.js"></script>
</body>
</html>
