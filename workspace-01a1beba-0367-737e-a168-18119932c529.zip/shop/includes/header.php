<?php
require_once __DIR__ . '/db.php';
$page_title = $page_title ?? SHOP_NAME;
$me = current_customer();
$flashes = take_flashes();
?>
<!doctype html>
<html lang="lo">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($page_title) ?> — <?= e(SHOP_NAME) ?></title>
<link rel="stylesheet" href="<?= e(BASE_URL) ?>/assets/css/style.css">
</head>
<body>
<header class="site-header">
  <div class="wrap header-in">
    <a class="brand" href="<?= e(BASE_URL) ?>/index.php">
      <span class="brand-mark">ສ</span>
      <span class="brand-text">
        <strong><?= e(SHOP_NAME) ?></strong>
        <small><?= e(SHOP_LATIN) ?> · ເສື້ອຜ້າລາວ</small>
      </span>
    </a>

    <form class="search" action="<?= e(BASE_URL) ?>/index.php" method="get" role="search">
      <input type="search" name="q" value="<?= e($_GET['q'] ?? '') ?>" placeholder="ຄົ້ນຫາເສື້ອຜ້າ...">
      <button type="submit" aria-label="ຄົ້ນຫາ">ຄົ້ນຫາ</button>
    </form>

    <nav class="nav">
      <a href="<?= e(BASE_URL) ?>/index.php">ໜ້າຫຼັກ</a>
      <a href="<?= e(BASE_URL) ?>/orders.php">ຄຳສັ່ງຊື້</a>
      <a class="cart-link" href="<?= e(BASE_URL) ?>/cart.php">
        ກະຕ່າ <span class="cart-count"><?= cart_count() ?></span>
      </a>
      <?php if ($me): ?>
        <div class="user-menu">
          <button class="user-btn" type="button"><?= e($me['full_name']) ?> ▾</button>
          <div class="user-drop">
            <a href="<?= e(BASE_URL) ?>/profile.php">ໂປຣໄຟລ໌</a>
            <a href="<?= e(BASE_URL) ?>/orders.php">ຄຳສັ່ງຊື້ຂອງຂ້ອຍ</a>
            <a href="<?= e(BASE_URL) ?>/logout.php">ອອກຈາກລະບົບ</a>
          </div>
        </div>
      <?php else: ?>
        <a href="<?= e(BASE_URL) ?>/login.php">ເຂົ້າສູ່ລະບົບ</a>
        <a class="btn btn-primary btn-sm" href="<?= e(BASE_URL) ?>/register.php">ສະໝັກ</a>
      <?php endif; ?>
    </nav>
  </div>
</header>

<?php if ($flashes): ?>
  <div class="wrap flash-stack">
    <?php foreach ($flashes as $f): ?>
      <div class="flash flash-<?= e($f['type']) ?>"><?= e($f['msg']) ?></div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<main class="wrap site-main">
