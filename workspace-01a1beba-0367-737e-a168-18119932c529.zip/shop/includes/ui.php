<?php
require_once __DIR__ . '/db.php';


/** ຕົວຊ່ວຍສະແດງຜົນ (UI helpers) */

function category_emoji(string $cat): string
{
    return [
        'ເສື້ອ'        => '👕',
        'ສິ້ນ'         => '👗',
        'ໂສ້ງ'        => '👖',
        'ໝວກ'         => '🧢',
        'ເກີບ'         => '👟',
        'ກະເປົ໋າ'       => '👜',
        'ເຄື່ອງປະດັບ'  => '💎',
    ][$cat] ?? '🧵';
}

function product_thumb(array $p, string $class = 'thumb'): string
{
    $emoji = category_emoji($p['category'] ?? '');
    $oos = ($p['status'] ?? '') === 'out_of_stock' || (int)($p['stock_qty'] ?? 1) === 0;
    return '<div class="' . e($class . ($oos ? ' thumb-oos' : '')) . '">' . $emoji
        . ($oos ? '<span class="badge badge-stock" style="color:#b91c1c;background:#fee2e2">ໝົດສະຕ໋ອກ</span>' : '')
        . '</div>';
}

function stock_badge(array $p): string
{
    $qty = (int)($p['stock_qty'] ?? 0);
    if ($qty <= 0) {
        return '<span class="badge" style="color:#b91c1c;background:#fee2e2">ໝົດ</span>';
    }
    if ($qty <= 5) {
        return '<span class="badge" style="color:#86550a;background:#fffbeb">ເຫຼືອ ' . $qty . '</span>';
    }
    return '';
}

/** ຂັ້ນຕອນຄຳສັ່ງຊື້ ສຳລັບ timeline */
function order_status_steps(string $status): array
{
    $all = ['pending', 'confirmed', 'packing', 'shipped', 'delivered'];
    if ($status === 'cancelled') {
        return [['ຍົກເລີກ', true]];
    }
    $idx = array_search($status, $all, true);
    $out = [];
    foreach ($all as $i => $s) {
        $out[] = [status_label($s)[0], $idx !== false && $i <= $idx];
    }
    return $out;
}
