<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/ui.php';

$q        = trim((string)($_GET['q'] ?? ''));
$category = trim((string)($_GET['cat'] ?? ''));

$sql    = "SELECT * FROM products WHERE status <> 'inactive'";
$params = [];

if ($q !== '') {
    $sql .= ' AND (product_name LIKE ? OR description LIKE ? OR brand LIKE ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like);
}
if ($category !== '') {
    $sql .= ' AND category = ?';
    $params[] = $category;
}
$sql .= ' ORDER BY (status = \'out_of_stock\'), created_at DESC, product_id DESC';
$products = q_all($sql, $params);
$categories = q_all("SELECT category, COUNT(*) AS c FROM products WHERE status <> 'inactive' GROUP BY category ORDER BY c DESC");

$latest = q_all("SELECT * FROM products WHERE status = 'active' ORDER BY created_at DESC, product_id DESC LIMIT 4");
$bestsellers = q_all(
    "SELECT p.*, COALESCE(SUM(oi.quantity), 0) AS sold
     FROM products p
     LEFT JOIN order_items oi ON oi.product_id = p.product_id
     LEFT JOIN orders o ON o.order_id = oi.order_id AND o.status <> 'cancelled'
     WHERE p.status = 'active'
     GROUP BY p.product_id, p.product_name, p.category, p.brand, p.size, p.color,
              p.description, p.price, p.cost_price, p.stock_qty, p.image_url, p.status, p.created_at
     ORDER BY sold DESC, p.product_id
     LIMIT 4"
);

$page_title = 'ໜ້າຫຼັກ';
require __DIR__ . '/includes/header.php';
?>

<?php if ($q === '' && $category === ''): ?>
<section class="hero">
  <div class="hero-copy">
    <span class="eyebrow">ເສື້ອຜ້າລາວ · ສັ່ງຊື້ອອນລາຍ</span>
    <h1>ເສື້ອຜ້າລາວ ທີ່ໜຸ່ມສະໄໝ ແລະ ມີຄຸນນະພາບ</h1>
    <p class="lead">
      ຄັດເລືອກຜ້າໄໝ ຜ້າຝ້າຍ ແລະ ລາຍພື້ນເມືອງ ຈາກຊ່າງທໍມືລາວ.
      ສັ່ງຊື້ໄດ້ທຸກວັນ ສົ່ງທົ່ວປະເທດ ພາຍໃນ 1–3 ວັນ.
    </p>
    <div class="hero-actions">
      <a class="btn btn-primary btn-lg" href="#products">ເບິ່ງສິນຄ້າທັງໝົດ</a>
      <a class="btn btn-outline btn-lg" href="<?= e(url('register.php')) ?>">ສະໝັກສະມາຊິກ</a>
    </div>
    <div class="hero-stats">
      <div><strong><?= count($categories) ?></strong><span>ໝວດສິນຄ້າ</span></div>
      <div><strong><?= (int)q_val("SELECT COUNT(*) FROM products WHERE status='active'") ?></strong><span>ລາຍການພ້ອມຂາຍ</span></div>
      <div><strong>1–3 ວັນ</strong><span>ສົ່ງທົ່ວປະເທດ</span></div>
    </div>
  </div>
  <div class="hero-art" aria-hidden="true">
    <span class="blob b1"></span>
    <span class="blob b2"></span>
    <span class="blob b3"></span>
    <span class="tag">👗 ລາຍພື້ນເມືອງລາວ · ທໍມື 100%</span>
  </div>
</section>

<section>
  <div class="section-head">
    <div>
      <span class="eyebrow">ໃໝ່ລ່າສຸດ</span>
      <h2>ເພີ່ມເຂົ້າມາໃໝ່</h2>
    </div>
    <a class="btn btn-ghost btn-sm" href="#products">ເບິ່ງທັງໝົດ →</a>
  </div>
  <div class="grid-products">
    <?php foreach ($latest as $p): ?>
      <article class="product-card">
        <a href="<?= e(url('product.php', ['id' => $p['product_id']])) ?>"><?= product_thumb($p) ?></a>
        <div class="pc-body">
          <span class="pc-cat"><?= e($p['category']) ?></span>
          <h3 class="pc-name"><a href="<?= e(url('product.php', ['id' => $p['product_id']])) ?>"><?= e($p['product_name']) ?></a></h3>
          <span class="pc-meta"><?= e($p['size'] ?: '-') ?> · <?= e($p['color'] ?: '-') ?></span>
          <div class="pc-foot">
            <span class="price"><?= money($p['price']) ?></span>
            <?= stock_badge($p) ?>
          </div>
        </div>
      </article>
    <?php endforeach; ?>
  </div>
</section>

<section>
  <div class="section-head">
    <div>
      <span class="eyebrow">ຂາຍດີ</span>
      <h2>ສິນຄ້າຂາຍດີ</h2>
    </div>
  </div>
  <div class="grid-products">
    <?php foreach ($bestsellers as $p): ?>
      <article class="product-card">
        <a href="<?= e(url('product.php', ['id' => $p['product_id']])) ?>"><?= product_thumb($p) ?></a>
        <div class="pc-body">
          <span class="pc-cat"><?= e($p['category']) ?> · ຂາຍແລ້ວ <?= (int)$p['sold'] ?></span>
          <h3 class="pc-name"><a href="<?= e(url('product.php', ['id' => $p['product_id']])) ?>"><?= e($p['product_name']) ?></a></h3>
          <span class="pc-meta"><?= e($p['size'] ?: '-') ?> · <?= e($p['color'] ?: '-') ?></span>
          <div class="pc-foot">
            <span class="price"><?= money($p['price']) ?></span>
            <?= stock_badge($p) ?>
          </div>
        </div>
      </article>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<section id="products">
  <div class="section-head">
    <div>
      <span class="eyebrow">ສິນຄ້າ</span>
      <h2>
        <?php if ($q !== ''): ?>
          ຜົນຄົ້ນຫາ “<?= e($q) ?>” — <?= count($products) ?> ລາຍການ
        <?php elseif ($category !== ''): ?>
          ໝວດ: <?= e($category) ?> — <?= count($products) ?> ລາຍການ
        <?php else: ?>
          ສິນຄ້າທັງໝົດ
        <?php endif; ?>
      </h2>
    </div>
    <?php if ($q !== '' || $category !== ''): ?>
      <a class="btn btn-outline btn-sm" href="<?= e(url('index.php')) ?>">✕ ລ້າງຕົວກອງ</a>
    <?php endif; ?>
  </div>

  <div class="chips">
    <a class="chip <?= $category === '' ? 'active' : '' ?>" href="<?= e(url('index.php', $q !== '' ? ['q' => $q] : [])) ?>">ທັງໝົດ</a>
    <?php foreach ($categories as $c): ?>
      <a class="chip <?= $category === $c['category'] ? 'active' : '' ?>"
         href="<?= e(url('index.php', array_filter(['cat' => $c['category'], 'q' => $q]))) ?>">
        <?= category_emoji($c['category']) ?> <?= e($c['category']) ?> <span class="muted">(<?= (int)$c['c'] ?>)</span>
      </a>
    <?php endforeach; ?>
  </div>

  <?php if (!$products): ?>
    <div class="card card-pad empty-state">
      <div class="big">🔍</div>
      <p>ບໍ່ພົບສິນຄ້າທີ່ຄົ້ນຫາ — ລອງຄົ້ນຫາຄຳອື່ນ ຫຼື ເບິ່ງສິນຄ້າທັງໝົດ.</p>
      <a class="btn btn-primary" href="<?= e(url('index.php')) ?>">ເບິ່ງສິນຄ້າທັງໝົດ</a>
    </div>
  <?php else: ?>
    <div class="grid-products">
      <?php foreach ($products as $p): ?>
        <article class="product-card">
          <a href="<?= e(url('product.php', ['id' => $p['product_id']])) ?>"><?= product_thumb($p) ?></a>
          <div class="pc-body">
            <span class="pc-cat"><?= e($p['category']) ?><?= $p['brand'] ? ' · ' . e($p['brand']) : '' ?></span>
            <h3 class="pc-name"><a href="<?= e(url('product.php', ['id' => $p['product_id']])) ?>"><?= e($p['product_name']) ?></a></h3>
            <span class="pc-meta">ຂະໜາດ <?= e($p['size'] ?: '-') ?> · ສີ <?= e($p['color'] ?: '-') ?></span>
            <div class="pc-foot">
              <span class="price"><?= money($p['price']) ?></span>
              <?php if ((int)$p['stock_qty'] > 0): ?>
                <form method="post" action="<?= e(url('cart.php')) ?>">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="add">
                  <input type="hidden" name="product_id" value="<?= (int)$p['product_id'] ?>">
                  <input type="hidden" name="qty" value="1">
                  <button class="btn btn-dark btn-sm" type="submit">+ ໃສ່ກະຕ່າ</button>
                </form>
              <?php else: ?>
                <?= stock_badge($p) ?>
              <?php endif; ?>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
