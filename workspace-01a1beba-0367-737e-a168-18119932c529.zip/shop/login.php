<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/ui.php';

$next = (string)($_GET['next'] ?? '');
$errors = [];
$identifier = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $identifier = trim((string)($_POST['identifier'] ?? ''));
    $password   = (string)($_POST['password'] ?? '');
    $next       = (string)($_POST['next'] ?? '');

    if ($identifier === '' || $password === '') {
        $errors[] = 'ກະລຸນາໃສ່ເບີໂທ/ອີເມວ ແລະ ລະຫັດຜ່ານ.';
    } else {
        $c = q_one(
            'SELECT * FROM customers WHERE phone = ? OR email = ? LIMIT 1',
            [$identifier, $identifier]
        );
        if ($c && password_verify($password, $c['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['customer_id'] = (int)$c['customer_id'];
            unset($_SESSION['is_admin']);
            flash('success', 'ຍິນດີຕ້ອນຮັບ, ' . $c['full_name'] . '!');
            $to = $next !== '' && str_starts_with($next, '.') === false ? $next : url('index.php');
            header('Location: ' . $to);
            exit;
        }
        $errors[] = 'ເບີໂທ/ອີເມວ ຫຼື ລະຫັດຜ່ານ ບໍ່ຖືກຕ້ອງ.';
    }
}

$page_title = 'ເຂົ້າສູ່ລະບົບ';
require __DIR__ . '/includes/header.php';
?>

<div class="auth-wrap">
  <div class="auth-logo">
    <span class="brand-mark" style="width:56px;height:56px;font-size:27px;border-radius:16px">ສ</span>
  </div>
  <div class="auth-card">
    <h1>ເຂົ້າສູ່ລະບົບ</h1>
    <p class="auth-sub">ເຂົ້າໃຊ້ດ້ວຍ ເບີໂທ ຫຼື ອີເມວ ຂອງທ່ານ</p>

    <?php if ($errors): ?>
      <div class="flash flash-error" style="margin-bottom:18px">
        <?php foreach ($errors as $er): ?><div><?= e($er) ?></div><?php endforeach; ?>
      </div>
    <?php endif; ?>

    <form method="post" class="form-grid">
      <?= csrf_field() ?>
      <input type="hidden" name="next" value="<?= e($next) ?>">
      <div class="field">
        <label for="identifier">ເບີໂທ ຫຼື ອີເມວ</label>
        <input id="identifier" type="text" name="identifier" value="<?= e($identifier) ?>" required autofocus
               placeholder="02055511111 ຫຼື you@example.com">
      </div>
      <div class="field">
        <label for="password">ລະຫັດຜ່ານ</label>
        <input id="password" type="password" name="password" required placeholder="••••••••">
      </div>
      <button class="btn btn-primary btn-block btn-lg" type="submit">ເຂົ້າສູ່ລະບົບ</button>
    </form>

    <p class="auth-foot">ຍັງບໍ່ມີບັນຊີ? <a href="<?= e(url('register.php')) ?>">ສະໝັກສະມາຊິກ</a></p>

    <div class="flash flash-info" style="margin-top:18px;font-size:13.5px">
      <strong>ບັນຊີທົດລອງ:</strong> ເບີໂທ <code>02055511111</code> · ລະຫັດຜ່ານ <code>123456</code>
    </div>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
