<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/db.php';
unset($_SESSION['customer_id']);
flash('info', 'ອອກຈາກລະບົບແລ້ວ.');
redirect('index.php');
