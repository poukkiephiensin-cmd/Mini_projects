<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/ui.php';

require_customer();
$me = current_customer();

$id = (int)($_GET['id'] ?? 0);
$order = q_one('SELECT * FROM orders WHERE order_id = ? AND customer_id = ?', [$id, $me['customer_id']]);

if (!$order) {
    flash('error', 'ບໍ່ພົບຄຳສັ່ງຊື້ນີ້.');
    redirect('orders.php');
}

$items = q_all(
    'SELECT oi.*, p.product_name, p.category FROM order_items oi
     JOIN products p ON p.product_id = oi.product_id WHERE oi.order_id = ? ORDER BY oi.item_id',
    [$id]
);
$payments = q_all('SELECT * FROM payments WHERE order_id = ? ORDER BY payment_id DESC', [$id]);
$steps = order_status_steps($order['status']);

$page_title = 'ຄຳສັ່ງຊື້ #' . (int)$order['order_id'];
require __DIR__ . '/includes/header.php';
?>

<nav class="small muted" style="margin-bottom:16px">
  <a href="<?= e(url('orders.php')) ?>">ຄຳສັ່ງຊື້</a> › <span>#<?= (int)$order['order_id'] ?></span>
</nav>

<div class="section-head" style="margin-top:0">
  <div>
    <span class="eyebrow"><?= date('d/m/Y H:i', strtotime($order['order_date'])) ?></span>
    <h1>ຄຳສັ່ງຊື້ #<?= (int)$order['order_id'] ?></h1>
  </div>
  <div><?= status_badge($order['status']) ?></div>
</div>

<div class="timeline" style="margin-bottom:26px">
  <?php foreach ($steps as [$label, $done]): ?>
    <div class="tl-step <?= $done ? 'done' : '' ?>"><?= e($label) ?></div>
  <?php endforeach; ?>
</div>

<div class="detail-grid">
  <div style="display:grid;gap:22px">
    <section class="card">
      <div class="card-head"><h2>ລາຍການສິນຄ້າ</h2></div>
      <div class="table-wrap">
        <table class="data">
          <thead><tr><th>ສິນຄ້າ</th><th>ຂະໜາດ/ສີ</th><th class="num">ຈຳນວນ</th><th class="num">ລາຄາ</th><th class="num">ລວມ</th></tr></thead>
          <tbody>
            <?php foreach ($items as $it): ?>
              <tr>
                <td><?= category_emoji($it['category']) ?> <?= e($it['product_name']) ?></td>
                <td class="muted"><?= e($it['size'] ?: '-') ?> / <?= e($it['color'] ?: '-') ?></td>
                <td class="num"><?= (int)$it['quantity'] ?></td>
                <td class="num"><?= money($it['unit_price']) ?></td>
                <td class="num"><strong><?= money($it['line_total']) ?></strong></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
          <tfoot>
            <tr><td colspan="4" class="num">ລວມຄ່າສິນຄ້າ</td><td class="num"><?= money($order['subtotal']) ?></td></tr>
            <tr><td colspan="4" class="num">ຄ່າຂົນສົ່ງ</td><td class="num"><?= money($order['shipping_fee']) ?></td></tr>
            <?php if ((float)$order['discount'] > 0): ?>
              <tr><td colspan="4" class="num">ສ່ວນຫຼຸດ</td><td class="num">−<?= money($order['discount']) ?></td></tr>
            <?php endif; ?>
            <tr><td colspan="4" class="num">ຍອດລວມ</td><td class="num"><?= money($order['total_amount']) ?></td></tr>
          </tfoot>
        </table>
      </div>
    </section>

    <section class="card">
      <div class="card-head"><h2>ການຊຳລະ</h2></div>
      <div class="card-pad">
        <?php if (!$payments): ?>
          <p class="muted">ຍັງບໍ່ມີລາຍການຊຳລະ.</p>
        <?php else: foreach ($payments as $pm): ?>
          <div style="display:flex;justify-content:space-between;align-items:center;gap:14px;padding:11px 0;border-bottom:1px solid var(--line);flex-wrap:wrap">
            <div>
              <div style="font-weight:600"><?= e(payment_label($pm['payment_method'])) ?></div>
              <div class="muted small">
                <?= money($pm['amount']) ?>
                <?= $pm['transaction_ref'] ? ' · ອ້າງອີງ ' . e($pm['transaction_ref']) : '' ?>
                <?= $pm['paid_at'] ? ' · ' . date('d/m/Y H:i', strtotime($pm['paid_at'])) : '' ?>
              </div>
            </div>
            <?= status_badge($pm['payment_status']) ?>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </section>
  </div>

  <aside style="display:grid;gap:18px">
    <div class="card card-pad">
      <h3 style="font-size:16px">ຂໍ້ມູນຈັດສົ່ງ</h3>
      <dl class="kv">
        <dt>ຜູ້ຮັບ</dt><dd><?= e($me['full_name']) ?></dd>
        <dt>ເບີໂທ</dt><dd><?= e($me['phone']) ?></dd>
        <dt>ທີ່ຢູ່</dt><dd><?= e($order['shipping_address']) ?></dd>
        <?php if ($order['note']): ?><dt>ໝາຍເຫດ</dt><dd><?= e($order['note']) ?></dd><?php endif; ?>
      </dl>
    </div>
    <div class="card card-pad">
      <a class="btn btn-outline btn-block" href="<?= e(url('orders.php')) ?>">← ກັບໄປລາຍການຄຳສັ່ງຊື້</a>
    </div>
  </aside>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
