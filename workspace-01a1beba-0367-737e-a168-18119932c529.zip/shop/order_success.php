<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/ui.php';

require_customer();
$me = current_customer();

$id = (int)($_GET['id'] ?? 0);
if ($id === 0 && !empty($_SESSION['last_order'])) {
    $id = (int)$_SESSION['last_order'];
}
$order = q_one('SELECT * FROM orders WHERE order_id = ? AND customer_id = ?', [$id, $me['customer_id']]);

if (!$order) {
    flash('error', 'ບໍ່ພົບຄຳສັ່ງຊື້ນີ້.');
    redirect('orders.php');
}

$items = q_all(
    'SELECT oi.*, p.product_name, p.category FROM order_items oi
     JOIN products p ON p.product_id = oi.product_id
     WHERE oi.order_id = ? ORDER BY oi.item_id',
    [$id]
);
$payments = q_all('SELECT * FROM payments WHERE order_id = ? ORDER BY payment_id DESC', [$id]);

$page_title = 'ສັ່ງຊື້ສຳເລັດ';
require __DIR__ . '/includes/header.php';
?>

<div class="steps">
  <span class="step on"><b>1</b> ກະຕ່າສິນຄ້າ</span>
  <span class="step on"><b>2</b> ທີ່ຢູ່ ແລະ ການຊຳລະ</span>
  <span class="step on"><b>3</b> ສຳເລັດ</span>
</div>

<div class="card card-pad" style="text-align:center;margin-bottom:24px">
  <div style="font-size:56px;line-height:1">✅</div>
  <h1 style="margin:10px 0 6px">ສັ່ງຊື້ສຳເລັດ!</h1>
  <p class="muted">ຄຳສັ່ງຊື້ເລກ <strong>#<?= (int)$order['order_id'] ?></strong> ຖືກບັນທຶກແລ້ວ.
    ທີມງານຈະຕິດຕໍ່ຢືນຢັນໃນໄວໆນີ້.</p>
  <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;margin-top:18px">
    <a class="btn btn-primary" href="<?= e(url('order_detail.php', ['id' => $order['order_id']])) ?>">ເບິ່ງລາຍລະອຽດ</a>
    <a class="btn btn-outline" href="<?= e(url('index.php')) ?>">ຊື້ຕໍ່</a>
  </div>
</div>

<div class="detail-grid">
  <div class="card">
    <div class="card-head">
      <h2>ລາຍການສິນຄ້າ</h2>
      <?= status_badge($order['status']) ?>
    </div>
    <div class="table-wrap">
      <table class="data">
        <thead>
          <tr><th>ສິນຄ້າ</th><th>ຂະໜາດ/ສີ</th><th class="num">ຈຳນວນ</th><th class="num">ລາຄາ</th><th class="num">ລວມ</th></tr>
        </thead>
        <tbody>
          <?php foreach ($items as $it): ?>
            <tr>
              <td><?= category_emoji($it['category']) ?> <?= e($it['product_name']) ?></td>
              <td class="muted"><?= e($it['size'] ?: '-') ?> / <?= e($it['color'] ?: '-') ?></td>
              <td class="num"><?= (int)$it['quantity'] ?></td>
              <td class="num"><?= money($it['unit_price']) ?></td>
              <td class="num"><strong><?= money($it['line_total']) ?></strong></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
        <tfoot>
          <tr><td colspan="4" class="num">ລວມຄ່າສິນຄ້າ</td><td class="num"><?= money($order['subtotal']) ?></td></tr>
          <tr><td colspan="4" class="num">ຄ່າຂົນສົ່ງ</td><td class="num"><?= money($order['shipping_fee']) ?></td></tr>
          <?php if ((float)$order['discount'] > 0): ?>
            <tr><td colspan="4" class="num">ສ່ວນຫຼຸດ</td><td class="num">−<?= money($order['discount']) ?></td></tr>
          <?php endif; ?>
          <tr><td colspan="4" class="num">ຍອດລວມ</td><td class="num"><?= money($order['total_amount']) ?></td></tr>
        </tfoot>
      </table>
    </div>
  </div>

  <aside style="display:grid;gap:18px">
    <div class="card card-pad">
      <h3 style="font-size:16px">ຂໍ້ມູນການສັ່ງຊື້</h3>
      <dl class="kv">
        <dt>ວັນທີ</dt><dd><?= date('d/m/Y H:i', strtotime($order['order_date'])) ?></dd>
        <dt>ຜູ້ຮັບ</dt><dd><?= e($me['full_name']) ?></dd>
        <dt>ທີ່ຢູ່</dt><dd><?= e($order['shipping_address']) ?></dd>
        <?php if ($order['note']): ?><dt>ໝາຍເຫດ</dt><dd><?= e($order['note']) ?></dd><?php endif; ?>
      </dl>
    </div>

    <?php if ($payments): ?>
    <div class="card card-pad">
      <h3 style="font-size:16px">ການຊຳລະ</h3>
      <?php foreach ($payments as $pm): ?>
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid var(--line)">
          <div>
            <div style="font-weight:600"><?= e(payment_label($pm['payment_method'])) ?></div>
            <div class="muted small"><?= money($pm['amount']) ?><?= $pm['transaction_ref'] ? ' · ' . e($pm['transaction_ref']) : '' ?></div>
          </div>
          <?= status_badge($pm['payment_status']) ?>
        </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </aside>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
