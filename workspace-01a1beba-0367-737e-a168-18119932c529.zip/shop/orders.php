<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/ui.php';

require_customer();
$me = current_customer();

$status = (string)($_GET['status'] ?? '');
$allowed = ['pending', 'confirmed', 'packing', 'shipped', 'delivered', 'cancelled'];

$sql = 'SELECT * FROM orders WHERE customer_id = ?';
$params = [$me['customer_id']];
if (in_array($status, $allowed, true)) {
    $sql .= ' AND status = ?';
    $params[] = $status;
}
$sql .= ' ORDER BY order_date DESC, order_id DESC';
$orders = q_all($sql, $params);

$counts = [];
foreach (q_all('SELECT status, COUNT(*) c FROM orders WHERE customer_id = ? GROUP BY status', [$me['customer_id']]) as $r) {
    $counts[$r['status']] = (int)$r['c'];
}
$totalOrders = array_sum($counts);

$page_title = 'ຄຳສັ່ງຊື້ຂອງຂ້ອຍ';
require __DIR__ . '/includes/header.php';
?>

<div class="section-head" style="margin-top:0">
  <div>
    <span class="eyebrow">ບັນຊີຂອງຂ້ອຍ</span>
    <h1>ຄຳສັ່ງຊື້</h1>
    <p class="muted">ທັງໝົດ <?= $totalOrders ?> ຄຳສັ່ງຊື້</p>
  </div>
  <a class="btn btn-outline btn-sm" href="<?= e(url('profile.php')) ?>">ໂປຣໄຟລ໌</a>
</div>

<div class="chips">
  <a class="chip <?= $status === '' ? 'active' : '' ?>" href="<?= e(url('orders.php')) ?>">ທັງໝົດ (<?= $totalOrders ?>)</a>
  <?php foreach ($allowed as $s): if (empty($counts[$s])) continue; ?>
    <a class="chip <?= $status === $s ? 'active' : '' ?>" href="<?= e(url('orders.php', ['status' => $s])) ?>">
      <?= e(status_label($s)[0]) ?> (<?= $counts[$s] ?>)
    </a>
  <?php endforeach; ?>
</div>

<?php if (!$orders): ?>
  <div class="card card-pad empty-state">
    <div class="big">🧾</div>
    <h2>ຍັງບໍ່ມີຄຳສັ່ງຊື້</h2>
    <p class="muted">ເມື່ອທ່ານສັ່ງຊື້ ລາຍການຈະສະແດງຢູ່ນີ້.</p>
    <a class="btn btn-primary" href="<?= e(url('index.php')) ?>">ເລື່ອງຊື້ສິນຄ້າ</a>
  </div>
<?php else: ?>
  <?php foreach ($orders as $o):
      $lines = q_all(
          'SELECT oi.*, p.product_name, p.category FROM order_items oi
           JOIN products p ON p.product_id = oi.product_id WHERE oi.order_id = ?',
          [$o['order_id']]
      );
      $steps = order_status_steps($o['status']);
  ?>
    <article class="order-card">
      <div class="oc-head">
        <div>
          <div class="order-code">#<?= (int)$o['order_id'] ?></div>
          <div class="muted small"><?= date('d/m/Y H:i', strtotime($o['order_date'])) ?></div>
        </div>
        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
          <?= status_badge($o['status']) ?>
          <strong><?= money($o['total_amount']) ?></strong>
        </div>
      </div>

      <div style="padding:14px 20px">
        <div class="timeline">
          <?php foreach ($steps as [$label, $done]): ?>
            <div class="tl-step <?= $done ? 'done' : '' ?>"><?= e($label) ?></div>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="table-wrap">
        <table class="data">
          <thead>
            <tr><th>ສິນຄ້າ</th><th>ຕົວຢ່າງ</th><th class="num">ຈຳນວນ</th><th class="num">ລວມ</th><th></th></tr>
          </thead>
          <tbody>
            <?php foreach ($lines as $l): ?>
              <tr>
                <td><?= category_emoji($l['category']) ?> <?= e($l['product_name']) ?></td>
                <td class="muted"><?= e($l['size'] ?: '-') ?> / <?= e($l['color'] ?: '-') ?></td>
                <td class="num"><?= (int)$l['quantity'] ?></td>
                <td class="num"><?= money($l['line_total']) ?></td>
                <td class="num">
                  <a class="btn btn-outline btn-sm" href="<?= e(url('order_detail.php', ['id' => $o['order_id']])) ?>">ລາຍລະອຽດ</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </article>
  <?php endforeach; ?>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
