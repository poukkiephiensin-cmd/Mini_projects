<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/ui.php';

$id = (int)($_GET['id'] ?? 0);
$p  = q_one('SELECT * FROM products WHERE product_id = ?', [$id]);

if (!$p) {
    http_response_code(404);
    $page_title = 'ບໍ່ພົບສິນຄ້າ';
    require __DIR__ . '/includes/header.php';
    echo '<div class="card card-pad empty-state"><div class="big">🔍</div>'
        . '<h2>ບໍ່ພົບສິນຄ້ານີ້</h2>'
        . '<p>ສິນຄ້າອາດຖືກລຶບ ຫຼື ປ່ຽນລິ້ງແລ້ວ.</p>'
        . '<a class="btn btn-primary" href="' . e(url('index.php')) . '">ກັບໜ້າຫຼັກ</a></div>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

// ສິນຄ້າໃກ້ຄຽງ
$related = q_all(
    'SELECT * FROM products WHERE category = ? AND product_id <> ? AND status = ? ORDER BY RAND() LIMIT 4',
    [$p['category'], $id, 'active']
);

$sold = (int)q_val(
    'SELECT COALESCE(SUM(oi.quantity),0) FROM order_items oi
     JOIN orders o ON o.order_id = oi.order_id AND o.status <> "cancelled"
     WHERE oi.product_id = ?',
    [$id]
);

$page_title = $p['product_name'];
require __DIR__ . '/includes/header.php';
?>

<nav class="small muted" style="margin-bottom:18px">
  <a href="<?= e(url('index.php')) ?>">ໜ້າຫຼັກ</a> ›
  <a href="<?= e(url('index.php', ['cat' => $p['category']])) ?>"><?= e($p['category']) ?></a> ›
  <span><?= e($p['product_name']) ?></span>
</nav>

<div style="display:grid;grid-template-columns:minmax(0,.95fr) minmax(0,1.05fr);gap:38px;align-items:start" class="product-detail">
  <div>
    <div style="border-radius:18px;overflow:hidden;border:1px solid var(--line);background:#fff">
      <?= product_thumb($p, 'thumb') ?>
    </div>
  </div>

  <div>
    <span class="eyebrow"><?= e($p['category']) ?><?= $p['brand'] ? ' · ' . e($p['brand']) : '' ?></span>
    <h1 style="margin-bottom:.25em"><?= e($p['product_name']) ?></h1>
    <div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin-bottom:18px">
      <span class="price" style="font-size:30px"><?= money($p['price']) ?></span>
      <?= status_badge($p['status']) ?>
      <span class="muted small">ຂາຍແລ້ວ <?= $sold ?> ຊິ້ນ</span>
    </div>

    <table class="data" style="margin-bottom:22px">
      <tbody>
        <tr><th style="width:130px">ຂະໜາດ</th><td><?= e($p['size'] ?: '-') ?></td></tr>
        <tr><th>ສີ</th><td><?= e($p['color'] ?: '-') ?></td></tr>
        <tr><th>ສະຕ໋ອກ</th><td>
          <?php if ((int)$p['stock_qty'] > 0): ?>
            ມີ <?= (int)$p['stock_qty'] ?> ຊິ້ນ
          <?php else: ?>
            <span style="color:#b91c1c">ໝົດສະຕ໋ອກ</span>
          <?php endif; ?>
        </td></tr>
        <tr><th>ລາຍລະອຽດ</th><td><?= nl2br(e($p['description'] ?: '-')) ?></td></tr>
      </tbody>
    </table>

    <?php if ($p['status'] !== 'inactive' && (int)$p['stock_qty'] > 0): ?>
      <form method="post" action="<?= e(url('cart.php')) ?>" style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="add">
        <input type="hidden" name="product_id" value="<?= (int)$p['product_id'] ?>">
        <div class="field" style="max-width:130px">
          <label for="qty">ຈຳນວນ</label>
          <input id="qty" type="number" name="qty" value="1" min="1" max="<?= (int)$p['stock_qty'] ?>">
        </div>
        <button class="btn btn-primary btn-lg" type="submit">ໃສ່ກະຕ່າ</button>
        <a class="btn btn-outline btn-lg" href="<?= e(url('cart.php')) ?>">ໄປທີ່ກະຕ່າ</a>
      </form>
    <?php else: ?>
      <div class="flash flash-warning">ສິນຄ້ານີ້ຍັງບໍ່ພ້ອມຂາຍ — ກະລຸນາເລືອກລາຍການອື່ນ.</div>
    <?php endif; ?>
  </div>
</div>

<?php if ($related): ?>
<section style="margin-top:52px">
  <div class="section-head"><div><span class="eyebrow">ໝວດດຽວກັນ</span><h2>ສິນຄ້າທີ່ຄ້າຍກັນ</h2></div></div>
  <div class="grid-products">
    <?php foreach ($related as $r): ?>
      <article class="product-card">
        <a href="<?= e(url('product.php', ['id' => $r['product_id']])) ?>"><?= product_thumb($r) ?></a>
        <div class="pc-body">
          <span class="pc-cat"><?= e($r['category']) ?></span>
          <h3 class="pc-name"><a href="<?= e(url('product.php', ['id' => $r['product_id']])) ?>"><?= e($r['product_name']) ?></a></h3>
          <span class="pc-meta"><?= e($r['size'] ?: '-') ?> · <?= e($r['color'] ?: '-') ?></span>
          <div class="pc-foot"><span class="price"><?= money($r['price']) ?></span></div>
        </div>
      </article>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
