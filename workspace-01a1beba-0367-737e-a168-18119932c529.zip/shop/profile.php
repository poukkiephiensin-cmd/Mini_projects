<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/ui.php';

require_customer();
$me = current_customer();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $fullName = trim((string)($_POST['full_name'] ?? ''));
    $gender   = (string)($_POST['gender'] ?? 'O');
    $email    = trim((string)($_POST['email'] ?? ''));
    $address  = trim((string)($_POST['address'] ?? ''));
    $city     = trim((string)($_POST['city'] ?? ''));
    $pw       = (string)($_POST['password'] ?? '');
    $pw2      = (string)($_POST['password2'] ?? '');

    if (mb_strlen($fullName) < 3) {
        $errors[] = 'ກະລຸນາໃສ່ຊື່ ແລະ ນາມສະກຸນ.';
    }
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'ອີເມວບໍ່ຖືກຕ້ອງ.';
    }
    if (!in_array($gender, ['M', 'F', 'O'], true)) {
        $gender = 'O';
    }
    if ($email !== '') {
        $dup = q_one('SELECT customer_id FROM customers WHERE email = ? AND customer_id <> ?', [$email, $me['customer_id']]);
        if ($dup) {
            $errors[] = 'ອີເມວນີ້ຖືກໃຊ້ໂດຍບັນຊີອື່ນແລ້ວ.';
        }
    }
    if ($pw !== '') {
        if (mb_strlen($pw) < 6) {
            $errors[] = 'ລະຫັດຜ່ານໃໝ່ຕ້ອງມີຢ່າງໜ້ອຍ 6 ຕົວອັກສອນ.';
        } elseif ($pw !== $pw2) {
            $errors[] = 'ລະຫັດຜ່ານໃໝ່ ທັງສອງບໍ່ກົງກັນ.';
        }
    }

    if (!$errors) {
        if ($pw !== '') {
            q_run(
                'UPDATE customers SET full_name=?, gender=?, email=?, address=?, city=?, password_hash=? WHERE customer_id=?',
                [$fullName, $gender, $email !== '' ? $email : null, $address !== '' ? $address : null,
                 $city !== '' ? $city : null, password_hash($pw, PASSWORD_DEFAULT), $me['customer_id']]
            );
        } else {
            q_run(
                'UPDATE customers SET full_name=?, gender=?, email=?, address=?, city=? WHERE customer_id=?',
                [$fullName, $gender, $email !== '' ? $email : null, $address !== '' ? $address : null,
                 $city !== '' ? $city : null, $me['customer_id']]
            );
        }
        flash('success', 'ບັນທຶກຂໍ້ມູນໂປຣໄຟລ໌ແລ້ວ.');
        redirect('profile.php');
    }
    $me = array_merge($me, [
        'full_name' => $fullName, 'gender' => $gender, 'email' => $email,
        'address' => $address, 'city' => $city,
    ]);
}

$stats = [
    'orders'  => (int)q_val('SELECT COUNT(*) FROM orders WHERE customer_id = ?', [$me['customer_id']]),
    'spent'   => (float)q_val('SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE customer_id = ? AND status <> "cancelled"', [$me['customer_id']]),
    'active'  => (int)q_val('SELECT COUNT(*) FROM orders WHERE customer_id = ? AND status IN ("pending","confirmed","packing","shipped")', [$me['customer_id']]),
];

$page_title = 'ໂປຣໄຟລ໌';
require __DIR__ . '/includes/header.php';
?>

<div class="section-head" style="margin-top:0">
  <div>
    <span class="eyebrow">ບັນຊີຂອງຂ້ອຍ</span>
    <h1>ໂປຣໄຟລ໌</h1>
  </div>
  <a class="btn btn-outline btn-sm" href="<?= e(url('orders.php')) ?>">ຄຳສັ່ງຊື້ຂອງຂ້ອຍ →</a>
</div>

<div class="stats" style="margin-bottom:26px">
  <div class="stat stat-ink"><div class="label">ຄຳສັ່ງຊື້ທັງໝົດ</div><div class="value"><?= $stats['orders'] ?></div></div>
  <div class="stat stat-accent"><div class="label">ກຳລັງດຳເນີນການ</div><div class="value"><?= $stats['active'] ?></div><div class="sub">ລໍຖ້າ / ກຳລັງສົ່ງ</div></div>
  <div class="stat stat-teal"><div class="label">ຍອດຊື້ທັງໝົດ</div><div class="value" style="font-size:22px"><?= money($stats['spent']) ?></div></div>
</div>

<?php if ($errors): ?>
  <div class="flash flash-error" style="margin-bottom:18px">
    <?php foreach ($errors as $er): ?><div>• <?= e($er) ?></div><?php endforeach; ?>
  </div>
<?php endif; ?>

<form method="post" class="card" style="max-width:760px">
  <?= csrf_field() ?>
  <div class="card-head"><h2>ຂໍ້ມູນສ່ວນຕົວ</h2></div>
  <div class="card-pad form-grid">
    <div class="form-row">
      <div class="field">
        <label for="full_name">ຊື່ ແລະ ນາມສະກຸນ</label>
        <input id="full_name" type="text" name="full_name" value="<?= e($me['full_name']) ?>" required>
      </div>
      <div class="field">
        <label for="gender">ເພດ</label>
        <select id="gender" name="gender">
          <option value="F" <?= $me['gender'] === 'F' ? 'selected' : '' ?>>ຍິງ</option>
          <option value="M" <?= $me['gender'] === 'M' ? 'selected' : '' ?>>ຊາຍ</option>
          <option value="O" <?= ($me['gender'] ?? 'O') === 'O' ? 'selected' : '' ?>>ອື່ນໆ</option>
        </select>
      </div>
    </div>

    <div class="form-row">
      <div class="field">
        <label>ເບີໂທ</label>
        <input type="text" value="<?= e($me['phone']) ?>" disabled>
        <span class="hint">ຕິດຕໍ່ຮ້ານ ເພື່ອປ່ຽນເບີໂທ</span>
      </div>
      <div class="field">
        <label for="email">ອີເມວ</label>
        <input id="email" type="email" name="email" value="<?= e($me['email'] ?? '') ?>">
      </div>
    </div>

    <div class="form-row">
      <div class="field">
        <label for="address">ທີ່ຢູ່</label>
        <input id="address" type="text" name="address" value="<?= e($me['address'] ?? '') ?>">
      </div>
      <div class="field">
        <label for="city">ແຂວງ / ນະຄອນ</label>
        <input id="city" type="text" name="city" value="<?= e($me['city'] ?? '') ?>">
      </div>
    </div>

    <hr style="border:0;border-top:1px solid var(--line);margin:8px 0">
    <h3 style="font-size:16px;margin:0">ປ່ຽນລະຫັດຜ່ານ</h3>
    <div class="form-row">
      <div class="field">
        <label for="password">ລະຫັດຜ່ານໃໝ່</label>
        <input id="password" type="password" name="password" minlength="6" placeholder="ປະຫວ່າງຖ້າບໍ່ປ່ຽນ">
      </div>
      <div class="field">
        <label for="password2">ຢືນຢັນລະຫັດຜ່ານໃໝ່</label>
        <input id="password2" type="password" name="password2" minlength="6">
      </div>
    </div>

    <div class="form-actions">
      <button class="btn btn-primary" type="submit">ບັນທຶກ</button>
      <a class="btn btn-ghost" href="<?= e(url('logout.php')) ?>">ອອກຈາກລະບົບ</a>
    </div>
  </div>
</form>

<?php require __DIR__ . '/includes/footer.php'; ?>
