<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/ui.php';

if (is_customer()) {
    redirect('index.php');
}

$errors = [];
$form = [
    'full_name' => '',
    'gender'    => 'F',
    'phone'     => '',
    'email'     => '',
    'address'   => '',
    'city'      => 'ວຽງຈັນ',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    foreach ($form as $k => $_) {
        $form[$k] = trim((string)($_POST[$k] ?? ''));
    }
    $password = (string)($_POST['password'] ?? '');
    $password2 = (string)($_POST['password2'] ?? '');

    if (mb_strlen($form['full_name']) < 3) {
        $errors[] = 'ກະລຸນາໃສ່ຊື່ ແລະ ນາມສະກຸນ.';
    }
    if (!preg_match('/^[0-9+\-\s]{8,20}$/', $form['phone'])) {
        $errors[] = 'ເບີໂທບໍ່ຖືກຕ້ອງ (ຕົວເລກ 8–20 ຕົວ).';
    }
    if ($form['email'] !== '' && !filter_var($form['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'ອີເມວບໍ່ຖືກຕ້ອງ.';
    }
    if (mb_strlen($password) < 6) {
        $errors[] = 'ລະຫັດຜ່ານຕ້ອງມີຢ່າງໜ້ອຍ 6 ຕົວອັກສອນ.';
    }
    if ($password !== $password2) {
        $errors[] = 'ລະຫັດຜ່ານ ທັງສອງບໍ່ກົງກັນ.';
    }
    if (!in_array($form['gender'], ['M', 'F', 'O'], true)) {
        $form['gender'] = 'O';
    }

    if (!$errors) {
        $dup = q_one('SELECT customer_id FROM customers WHERE phone = ? OR (email IS NOT NULL AND email = ?)', [$form['phone'], $form['email']]);
        if ($dup) {
            $errors[] = 'ເບີໂທ ຫຼື ອີເມວນີ້ ຖືກໃຊ້ແລ້ວ.';
        }
    }

    if (!$errors) {
        try {
            q_run(
                'INSERT INTO customers (full_name, gender, phone, email, password_hash, address, city)
                 VALUES (?, ?, ?, ?, ?, ?, ?)',
                [
                    $form['full_name'],
                    $form['gender'],
                    $form['phone'],
                    $form['email'] !== '' ? $form['email'] : null,
                    password_hash($password, PASSWORD_DEFAULT),
                    $form['address'] !== '' ? $form['address'] : null,
                    $form['city'] !== '' ? $form['city'] : null,
                ]
            );
            $id = (int)db()->lastInsertId();
            session_regenerate_id(true);
            $_SESSION['customer_id'] = $id;
            flash('success', 'ສ້າງບັນຊີສຳເລັດ! ຍິນດີຕ້ອນຮັບ ' . $form['full_name'] . '.');
            redirect('index.php');
        } catch (PDOException $ex) {
            $errors[] = 'ບັນທຶກບໍ່ສຳເລັດ: ' . $ex->getMessage();
        }
    }
}

$page_title = 'ສະໝັກສະມາຊິກ';
require __DIR__ . '/includes/header.php';
?>

<div class="auth-wrap" style="max-width:560px">
  <div class="auth-card">
    <h1>ສ້າງບັນຊີໃໝ່</h1>
    <p class="auth-sub">ສະໝັກເພື່ອສັ່ງຊື້ ແລະ ຕິດຕາມຄຳສັ່ງຊື້ຂອງທ່ານ</p>

    <?php if ($errors): ?>
      <div class="flash flash-error" style="margin-bottom:18px">
        <?php foreach ($errors as $er): ?><div>• <?= e($er) ?></div><?php endforeach; ?>
      </div>
    <?php endif; ?>

    <form method="post" class="form-grid">
      <?= csrf_field() ?>
      <div class="field">
        <label for="full_name">ຊື່ ແລະ ນາມສະກຸນ <span style="color:#b91c1c">*</span></label>
        <input id="full_name" type="text" name="full_name" value="<?= e($form['full_name']) ?>" required>
      </div>

      <div class="form-row">
        <div class="field">
          <label for="phone">ເບີໂທ <span style="color:#b91c1c">*</span></label>
          <input id="phone" type="tel" name="phone" value="<?= e($form['phone']) ?>" required placeholder="02055511111">
        </div>
        <div class="field">
          <label for="gender">ເພດ</label>
          <select id="gender" name="gender">
            <option value="F" <?= $form['gender'] === 'F' ? 'selected' : '' ?>>ຍິງ</option>
            <option value="M" <?= $form['gender'] === 'M' ? 'selected' : '' ?>>ຊາຍ</option>
            <option value="O" <?= $form['gender'] === 'O' ? 'selected' : '' ?>>ອື່ນໆ</option>
          </select>
        </div>
      </div>

      <div class="field">
        <label for="email">ອີເມວ</label>
        <input id="email" type="email" name="email" value="<?= e($form['email']) ?>" placeholder="you@example.com">
        <span class="hint">ບໍ່ບັງຄັບ · ໃຊ້ສຳລັບເຂົ້າສູ່ລະບົບ</span>
      </div>

      <div class="form-row">
        <div class="field">
          <label for="address">ທີ່ຢູ່</label>
          <input id="address" type="text" name="address" value="<?= e($form['address']) ?>" placeholder="ບ້ານ, ຖະໜົນ">
        </div>
        <div class="field">
          <label for="city">ແຂວງ / ນະຄອນ</label>
          <input id="city" type="text" name="city" value="<?= e($form['city']) ?>">
        </div>
      </div>

      <div class="form-row">
        <div class="field">
          <label for="password">ລະຫັດຜ່ານ <span style="color:#b91c1c">*</span></label>
          <input id="password" type="password" name="password" required minlength="6">
          <span class="hint">ຢ່າງໜ້ອຍ 6 ຕົວອັກສອນ</span>
        </div>
        <div class="field">
          <label for="password2">ຢືນຢັນລະຫັດຜ່ານ <span style="color:#b91c1c">*</span></label>
          <input id="password2" type="password" name="password2" required minlength="6">
        </div>
      </div>

      <button class="btn btn-primary btn-block btn-lg" type="submit">ສ້າງບັນຊີ</button>
    </form>

    <p class="auth-foot">ມີບັນຊີແລ້ວ? <a href="<?= e(url('login.php')) ?>">ເຂົ້າສູ່ລະບົບ</a></p>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
